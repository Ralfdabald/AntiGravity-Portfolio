﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: Payment.cs
//PURPOSE: This model defines the structure of the Payment entity, representing payments made by customers for properties in the JasperGreen application.
//INITIALIZE: The Payment model is used to track payments within the system, linked to customers and properties. A migration should be created 
// to add the Payment table to the database, and the necessary relationships to the Customer and Property models must be configured in 
// the database context.
//INPUT: The properties represent the data that is input for payments, including the amount, payment date, payment type, and relevant foreign 
// keys for customer and property.
//PROCESS: Stores payment details, such as the amount, payment type, and payment date, for each customer associated with a property. 
// It supports linking the payments to specific customers and properties.
//OUTPUT: The entity records payment information, which can be queried and used for financial analysis, customer tracking, 
// and reporting purposes in the JasperGreen application.
//TERMINATE: The payment data will be stored in the database via Entity Framework Core. The connection is managed by the EF Core context 
// throughout the application runtime.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

using System.ComponentModel.DataAnnotations;

namespace JasperGreenTeam11.Models
{
    public class Payment
    {
        public int PaymentId { get; set; } // Primary Key
        
        public int ProvideServiceId { get; set; }
        public ProvideService? ProvideService { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Amount must be > $0")]
        public decimal Amount { get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }

        public string? PaymentMethod { get; set; }

        // Foreign Key - Customer
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }
    }
}
