﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;
using System.Xml.Linq;
//AUTHOR:   Zoe Cruz, Cassandra Elizondo, Collin Fuchs, Josh High, Tyler Kwan
//Our group (ALL OF US) completed our student evaluations!
//COURSE:   ISTM 250.501
//FORM:  FRMVendor.cs
//PURPOSE: Create a form that displays the information for all of the vendors,
//   allows a user to change vendor information, allows the user to switch between
//   vendors, and saves the changed information if valid.
//INPUT:   An XML file with each vendor's name, address, city, state, sales rep,
//   phone number, zipcode, sales year to date, comments, and defualt discount.
//PROCESS: Close is used to close the form when the user clicks the close button.
//   The order is validated if the user enters information into all textboxes.
//   A messagebox asking the user if they want to save changes or not. SaveData()
//   is used to save the information if the user clicks "yes" to messagebox or save
//   button. FillVendorTextbox() inputs vendor info for the next or prev vendor.
//OUTPUT:  All of the Vendor Information and a messagebox asking the user to save info.
//HONOR CODE: “On my honor, as an Aggie, I have neither given  
//   nor received unauthorized aid on this academic  
//   work.”
namespace GroupBProject1
{
    public partial class FRMVendor : Form
    {
        public FRMVendor()
        {
            InitializeComponent();
        }

        //variable and list declaration
        private List<Vendor> lstVendor = null;
        Vendor SaveVendor = null;
        int intDefaultDiscount = 0;
        int intVendorIndexCounter = 0;
        bool isDataSaved = true;

        /// <summary>
        /// loads the textboxes with vendor info when the form loads
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMVendor_Load(object sender, EventArgs e)
        {
            lstVendor = VendorDB.GetVendors();
            FillVendorTextBox();
            isDataSaved = true;
        }
        /// <summary>
        /// fills textboxes in groupbox with the appropriate vendor's information
        /// </summary>
        private void FillVendorTextBox()
        {
            //clears the textboxes of all vendor info
            ClearTextBoxes();

            //loops the last vendor back to the first one and vice versa
            if(intVendorIndexCounter == lstVendor.Count)
            {
                intVendorIndexCounter = 0;
            }
            else if (intVendorIndexCounter == -1)
            {
                intVendorIndexCounter = lstVendor.Count - 1;
            }
            
            // gets the selected vendors info based on index
            Vendor VendorSelected = lstVendor[intVendorIndexCounter];

            //displays all vendor information in txtboxes
            TXTAddress.Text = VendorSelected.Address;
            TXTName.Text = VendorSelected.Name;
            TXTAddress.Text = VendorSelected.Address;
            TXTCity.Text = VendorSelected.City;
            TXTState.Text = VendorSelected.State;
            TXTZipCode.Text = VendorSelected.Zip;
            TXTPhone.Text = VendorSelected.Phone;
            TXTYearToDate.Text = VendorSelected.YTD.ToString();
            TXTComment.Text = VendorSelected.Comment;
            TXTSalesRep.Text = VendorSelected.Contact;

            //checks matching radiobox from the users default discount value
            if (VendorSelected.DefaultDiscount == 10)
            {
                RDO10days.Checked = true;
            }
            else if (VendorSelected.DefaultDiscount == 15)
            {
                RDO15days.Checked = true;
            }
            else if (VendorSelected.DefaultDiscount == 20)
            {
                RDO20days.Checked = true;
            }
            //data is unchanged by user so sets bool to true
            isDataSaved = true;
        }
        /// <summary>
        /// asks user if they want to save changes before moving to next vendor info
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNNext_Click(object sender, EventArgs e)
        {
            //save changes if data is changed
            if (isDataSaved == false)
            {
                //prompts question to user
                DialogResult button = MessageBox.Show("Do you want to save your changes?", "Unsaved Data",
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                //validates then saves data if user clicks yes from messagebox
                //displays next vendor information
                if (button == DialogResult.Yes)
                {
                    if (IsValidData())
                    {
                        SaveData();
                        intVendorIndexCounter += 1;
                        ClearTextBoxes();
                        FillVendorTextBox();
                    }
                }
                //displays next vendor information if user clicks no
                else if (button == DialogResult.No)
                {
                    intVendorIndexCounter += 1;
                    ClearTextBoxes();
                    FillVendorTextBox();
                }
            }
            //if nothing is changed, clears the textboxes, and displays next vendor info
            else
            {
                intVendorIndexCounter += 1;
                ClearTextBoxes();
                FillVendorTextBox();
            }
        }
        /// <summary>
        /// asks user if they want to save changes before moving to prev vendor info
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNPrevious_Click(object sender, EventArgs e)
        {
            //save changes if data is changed
            if (isDataSaved == false)
            {
                //prompts question to user
                DialogResult button = MessageBox.Show("Do you want to save your changes?", "Unsaved Data",
                MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                //validates then saves data if user clicks yes from messagebox
                //displays prev vendor information
                if (button == DialogResult.Yes)
                {
                    if (IsValidData())
                    {
                        SaveData();
                        intVendorIndexCounter -= 1;
                        ClearTextBoxes();
                        FillVendorTextBox();
                    }
                }
                //displays prev vendor information if user clicks no
                else if (button == DialogResult.No)
                {
                    intVendorIndexCounter -= 1;
                    ClearTextBoxes();
                    FillVendorTextBox();
                }
            }
            //if nothing is changed, clears the textboxes, and displays prev vendor info
            else
            {
                intVendorIndexCounter -= 1;
                ClearTextBoxes();
                FillVendorTextBox();
            }
        }
        /// <summary>
        /// validates then saves the data if the user clicks save button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNSave_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                SaveData();
            }
        }
        /// <summary>
        /// clears all textboxes in the groupbox
        /// </summary>
        private void ClearTextBoxes()
        {
            foreach (TextBox TXTBox in GBXVendor.Controls.OfType<TextBox>())
            {
                TXTBox.Clear();
            }
        }
        /// <summary>
        /// closes the form when user clicks close button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNClose_Click(object sender, EventArgs e)
        {
            Close();
        }
        /// <summary>
        /// asks user if they want to save changes when they attempt to close form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMVendor_FormClosing(object sender, FormClosingEventArgs e)
        {
            //prompts question only if there have been changes to form
            if (isDataSaved == false)
            {
                //prompts question to user
                DialogResult button = MessageBox.Show("Do you want to save your changes?", "Unsaved Data",
                    MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                if (button == DialogResult.Yes)
                {
                    //validates then saves data if the user clicks yes
                    if (IsValidData())
                        SaveData();
                    else
                        e.Cancel = true;
                }
                //closes the messagebox if the user clicks cancel
                if (button == DialogResult.Cancel)
                {
                    e.Cancel = true;
                }
            }
        }

        /// <summary>
        /// sets the data saved boolean to false if any txtboxes have been changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TXTYearToDate_TextChanged(object sender, EventArgs e)
        {
            isDataSaved = false;
        }
        /// <summary>
        /// sets the data saved boolean to false if any of the radiobuttons have been changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RDO15days_CheckedChanged(object sender, EventArgs e)
        {
            isDataSaved = false;
        }

        /// <summary>
        /// uses the validator class to validate the vendor information
        /// </summary>
        /// <returns></returns>
        private bool IsValidData()
        {
            //makes sure that all vendor info txtboxes have user input
            return Validator.IsPresent(TXTName) &&
               Validator.IsPresent(TXTYearToDate) &&
               Validator.IsPresent(TXTAddress) &&
               Validator.IsPresent(TXTState) &&
               Validator.IsPresent(TXTSalesRep) &&
               Validator.IsPresent(TXTCity) &&
               Validator.IsPresent(TXTZipCode);
        }

        /// <summary>
        /// saves the changed info if the user chooses to do so
        /// </summary>
        private void SaveData()
        {
            //sets the default discount to whichever radio button is checked
            if (RDO10days.Checked == true)
            {
                intDefaultDiscount = 10;
            }
            else if (RDO15days.Checked == true)
            {
                intDefaultDiscount = 15;
            }
            else if (RDO20days.Checked == true)
            {
                intDefaultDiscount = 20;
            }

            //clears the vendor list of previous unchanged information
            lstVendor.Remove(lstVendor[intVendorIndexCounter]);

            //saves the changes made by user to vendor class
            SaveVendor = new Vendor(TXTName.Text, TXTAddress.Text, TXTCity.Text, TXTState.Text, TXTZipCode.Text,
            TXTPhone.Text, Convert.ToDecimal(TXTYearToDate.Text), TXTComment.Text, TXTSalesRep.Text, intDefaultDiscount);

            //inserts change saved into vendor list
            lstVendor.Insert(intVendorIndexCounter, SaveVendor);
            //uses SaveVendors method to save list of vendor info to XML file
            VendorDB.SaveVendors(lstVendor);
            //tells user that info was saved
            MessageBox.Show("Information Saved!");
            isDataSaved = true;
        }
    }
}
