﻿namespace GroupBProject1
{
    partial class FRMVendor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTNNext = new System.Windows.Forms.Button();
            this.BTNPrevious = new System.Windows.Forms.Button();
            this.BTNSave = new System.Windows.Forms.Button();
            this.BTNClose = new System.Windows.Forms.Button();
            this.RDO15days = new System.Windows.Forms.RadioButton();
            this.RDO10days = new System.Windows.Forms.RadioButton();
            this.RDO20days = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.TXTName = new System.Windows.Forms.TextBox();
            this.TXTAddress = new System.Windows.Forms.TextBox();
            this.TXTCity = new System.Windows.Forms.TextBox();
            this.TXTState = new System.Windows.Forms.TextBox();
            this.TXTZipCode = new System.Windows.Forms.TextBox();
            this.TXTPhone = new System.Windows.Forms.TextBox();
            this.TXTYearToDate = new System.Windows.Forms.TextBox();
            this.TXTComment = new System.Windows.Forms.TextBox();
            this.TXTSalesRep = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.GBXVendor = new System.Windows.Forms.GroupBox();
            this.GBXVendor.SuspendLayout();
            this.SuspendLayout();
            // 
            // BTNNext
            // 
            this.BTNNext.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNNext.Location = new System.Drawing.Point(421, 35);
            this.BTNNext.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BTNNext.Name = "BTNNext";
            this.BTNNext.Size = new System.Drawing.Size(95, 30);
            this.BTNNext.TabIndex = 4;
            this.BTNNext.Text = "Next";
            this.BTNNext.UseVisualStyleBackColor = false;
            this.BTNNext.Click += new System.EventHandler(this.BTNNext_Click);
            // 
            // BTNPrevious
            // 
            this.BTNPrevious.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNPrevious.Location = new System.Drawing.Point(421, 73);
            this.BTNPrevious.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BTNPrevious.Name = "BTNPrevious";
            this.BTNPrevious.Size = new System.Drawing.Size(95, 30);
            this.BTNPrevious.TabIndex = 5;
            this.BTNPrevious.Text = "Previous";
            this.BTNPrevious.UseVisualStyleBackColor = false;
            this.BTNPrevious.Click += new System.EventHandler(this.BTNPrevious_Click);
            // 
            // BTNSave
            // 
            this.BTNSave.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNSave.Location = new System.Drawing.Point(421, 110);
            this.BTNSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BTNSave.Name = "BTNSave";
            this.BTNSave.Size = new System.Drawing.Size(95, 30);
            this.BTNSave.TabIndex = 6;
            this.BTNSave.Text = "Save";
            this.BTNSave.UseVisualStyleBackColor = false;
            this.BTNSave.Click += new System.EventHandler(this.BTNSave_Click);
            // 
            // BTNClose
            // 
            this.BTNClose.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BTNClose.Location = new System.Drawing.Point(421, 146);
            this.BTNClose.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BTNClose.Name = "BTNClose";
            this.BTNClose.Size = new System.Drawing.Size(95, 30);
            this.BTNClose.TabIndex = 7;
            this.BTNClose.Text = "Close";
            this.BTNClose.UseVisualStyleBackColor = false;
            this.BTNClose.Click += new System.EventHandler(this.BTNClose_Click);
            // 
            // RDO15days
            // 
            this.RDO15days.AutoSize = true;
            this.RDO15days.BackColor = System.Drawing.Color.Transparent;
            this.RDO15days.Location = new System.Drawing.Point(71, 401);
            this.RDO15days.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RDO15days.Name = "RDO15days";
            this.RDO15days.Size = new System.Drawing.Size(75, 20);
            this.RDO15days.TabIndex = 2;
            this.RDO15days.Text = "15 days";
            this.RDO15days.UseVisualStyleBackColor = false;
            this.RDO15days.CheckedChanged += new System.EventHandler(this.RDO15days_CheckedChanged);
            // 
            // RDO10days
            // 
            this.RDO10days.AutoSize = true;
            this.RDO10days.BackColor = System.Drawing.Color.Transparent;
            this.RDO10days.Location = new System.Drawing.Point(71, 373);
            this.RDO10days.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RDO10days.Name = "RDO10days";
            this.RDO10days.Size = new System.Drawing.Size(75, 20);
            this.RDO10days.TabIndex = 1;
            this.RDO10days.Text = "10 days";
            this.RDO10days.UseVisualStyleBackColor = false;
            this.RDO10days.CheckedChanged += new System.EventHandler(this.RDO15days_CheckedChanged);
            // 
            // RDO20days
            // 
            this.RDO20days.AutoSize = true;
            this.RDO20days.BackColor = System.Drawing.Color.Transparent;
            this.RDO20days.Location = new System.Drawing.Point(71, 430);
            this.RDO20days.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.RDO20days.Name = "RDO20days";
            this.RDO20days.Size = new System.Drawing.Size(75, 20);
            this.RDO20days.TabIndex = 3;
            this.RDO20days.Text = "20 days";
            this.RDO20days.UseVisualStyleBackColor = false;
            this.RDO20days.CheckedChanged += new System.EventHandler(this.RDO15days_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "Name:";
            // 
            // TXTName
            // 
            this.TXTName.Location = new System.Drawing.Point(111, 43);
            this.TXTName.Margin = new System.Windows.Forms.Padding(4);
            this.TXTName.Name = "TXTName";
            this.TXTName.Size = new System.Drawing.Size(232, 22);
            this.TXTName.TabIndex = 9;
            this.TXTName.Tag = "Name";
            this.TXTName.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // TXTAddress
            // 
            this.TXTAddress.Location = new System.Drawing.Point(111, 75);
            this.TXTAddress.Margin = new System.Windows.Forms.Padding(4);
            this.TXTAddress.Name = "TXTAddress";
            this.TXTAddress.Size = new System.Drawing.Size(232, 22);
            this.TXTAddress.TabIndex = 10;
            this.TXTAddress.Tag = "Address";
            this.TXTAddress.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // TXTCity
            // 
            this.TXTCity.Location = new System.Drawing.Point(111, 107);
            this.TXTCity.Margin = new System.Windows.Forms.Padding(4);
            this.TXTCity.Name = "TXTCity";
            this.TXTCity.Size = new System.Drawing.Size(232, 22);
            this.TXTCity.TabIndex = 11;
            this.TXTCity.Tag = "City";
            this.TXTCity.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // TXTState
            // 
            this.TXTState.Location = new System.Drawing.Point(111, 139);
            this.TXTState.Margin = new System.Windows.Forms.Padding(4);
            this.TXTState.Name = "TXTState";
            this.TXTState.Size = new System.Drawing.Size(232, 22);
            this.TXTState.TabIndex = 12;
            this.TXTState.Tag = "State";
            this.TXTState.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // TXTZipCode
            // 
            this.TXTZipCode.Location = new System.Drawing.Point(111, 171);
            this.TXTZipCode.Margin = new System.Windows.Forms.Padding(4);
            this.TXTZipCode.Name = "TXTZipCode";
            this.TXTZipCode.Size = new System.Drawing.Size(232, 22);
            this.TXTZipCode.TabIndex = 13;
            this.TXTZipCode.Tag = "Zip Code";
            this.TXTZipCode.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // TXTPhone
            // 
            this.TXTPhone.Location = new System.Drawing.Point(111, 204);
            this.TXTPhone.Margin = new System.Windows.Forms.Padding(4);
            this.TXTPhone.Name = "TXTPhone";
            this.TXTPhone.Size = new System.Drawing.Size(232, 22);
            this.TXTPhone.TabIndex = 14;
            this.TXTPhone.Tag = "Phone";
            this.TXTPhone.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // TXTYearToDate
            // 
            this.TXTYearToDate.Location = new System.Drawing.Point(111, 236);
            this.TXTYearToDate.Margin = new System.Windows.Forms.Padding(4);
            this.TXTYearToDate.Name = "TXTYearToDate";
            this.TXTYearToDate.Size = new System.Drawing.Size(232, 22);
            this.TXTYearToDate.TabIndex = 15;
            this.TXTYearToDate.Tag = "Year To Date";
            this.TXTYearToDate.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // TXTComment
            // 
            this.TXTComment.Location = new System.Drawing.Point(111, 268);
            this.TXTComment.Margin = new System.Windows.Forms.Padding(4);
            this.TXTComment.Name = "TXTComment";
            this.TXTComment.Size = new System.Drawing.Size(232, 22);
            this.TXTComment.TabIndex = 16;
            this.TXTComment.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // TXTSalesRep
            // 
            this.TXTSalesRep.Location = new System.Drawing.Point(111, 302);
            this.TXTSalesRep.Margin = new System.Windows.Forms.Padding(4);
            this.TXTSalesRep.Name = "TXTSalesRep";
            this.TXTSalesRep.Size = new System.Drawing.Size(232, 22);
            this.TXTSalesRep.TabIndex = 17;
            this.TXTSalesRep.Tag = "Sales Rep";
            this.TXTSalesRep.TextChanged += new System.EventHandler(this.TXTYearToDate_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 78);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Address:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 107);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 16);
            this.label3.TabIndex = 19;
            this.label3.Text = "City:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 139);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 16);
            this.label4.TabIndex = 20;
            this.label4.Text = "State:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(38, 174);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "Zip Code:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(54, 204);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 16);
            this.label6.TabIndex = 22;
            this.label6.Text = "Phone:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 239);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 16);
            this.label7.TabIndex = 23;
            this.label7.Text = "Year to Date:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(36, 271);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 16);
            this.label8.TabIndex = 24;
            this.label8.Text = "Comment:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(29, 305);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 16);
            this.label9.TabIndex = 25;
            this.label9.Text = "Sales Rep:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 342);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(107, 16);
            this.label10.TabIndex = 26;
            this.label10.Text = "Default Discount:";
            // 
            // GBXVendor
            // 
            this.GBXVendor.Controls.Add(this.TXTYearToDate);
            this.GBXVendor.Controls.Add(this.label10);
            this.GBXVendor.Controls.Add(this.RDO15days);
            this.GBXVendor.Controls.Add(this.label9);
            this.GBXVendor.Controls.Add(this.RDO10days);
            this.GBXVendor.Controls.Add(this.label8);
            this.GBXVendor.Controls.Add(this.RDO20days);
            this.GBXVendor.Controls.Add(this.label7);
            this.GBXVendor.Controls.Add(this.label1);
            this.GBXVendor.Controls.Add(this.label6);
            this.GBXVendor.Controls.Add(this.TXTName);
            this.GBXVendor.Controls.Add(this.label5);
            this.GBXVendor.Controls.Add(this.TXTAddress);
            this.GBXVendor.Controls.Add(this.label4);
            this.GBXVendor.Controls.Add(this.TXTCity);
            this.GBXVendor.Controls.Add(this.label3);
            this.GBXVendor.Controls.Add(this.TXTState);
            this.GBXVendor.Controls.Add(this.label2);
            this.GBXVendor.Controls.Add(this.TXTZipCode);
            this.GBXVendor.Controls.Add(this.TXTSalesRep);
            this.GBXVendor.Controls.Add(this.TXTPhone);
            this.GBXVendor.Controls.Add(this.TXTComment);
            this.GBXVendor.Location = new System.Drawing.Point(16, 6);
            this.GBXVendor.Margin = new System.Windows.Forms.Padding(4);
            this.GBXVendor.Name = "GBXVendor";
            this.GBXVendor.Padding = new System.Windows.Forms.Padding(4);
            this.GBXVendor.Size = new System.Drawing.Size(365, 459);
            this.GBXVendor.TabIndex = 27;
            this.GBXVendor.TabStop = false;
            this.GBXVendor.Text = "Vendor:";
            // 
            // FRMVendor
            // 
            this.AcceptButton = this.BTNSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.BTNClose;
            this.ClientSize = new System.Drawing.Size(551, 478);
            this.Controls.Add(this.GBXVendor);
            this.Controls.Add(this.BTNClose);
            this.Controls.Add(this.BTNSave);
            this.Controls.Add(this.BTNPrevious);
            this.Controls.Add(this.BTNNext);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FRMVendor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vendors ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FRMVendor_FormClosing);
            this.Load += new System.EventHandler(this.FRMVendor_Load);
            this.GBXVendor.ResumeLayout(false);
            this.GBXVendor.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button BTNNext;
        private System.Windows.Forms.Button BTNPrevious;
        private System.Windows.Forms.Button BTNSave;
        private System.Windows.Forms.Button BTNClose;
        private System.Windows.Forms.RadioButton RDO15days;
        private System.Windows.Forms.RadioButton RDO10days;
        private System.Windows.Forms.RadioButton RDO20days;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TXTName;
        private System.Windows.Forms.TextBox TXTAddress;
        private System.Windows.Forms.TextBox TXTCity;
        private System.Windows.Forms.TextBox TXTState;
        private System.Windows.Forms.TextBox TXTZipCode;
        private System.Windows.Forms.TextBox TXTPhone;
        private System.Windows.Forms.TextBox TXTYearToDate;
        private System.Windows.Forms.TextBox TXTComment;
        private System.Windows.Forms.TextBox TXTSalesRep;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox GBXVendor;
    }
}