global using Xunit;
global using Microsoft.AspNetCore.Mvc;
global using SportsPro.Models;
global using Moq;