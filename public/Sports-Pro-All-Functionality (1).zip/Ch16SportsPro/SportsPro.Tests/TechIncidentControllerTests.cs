﻿using Microsoft.AspNetCore.Mvc.ViewFeatures;  // for ITempDataDictionary
using Microsoft.AspNetCore.Http;              // for IHttpContextAccessor and ISession
using SportsPro.Controllers;

namespace SportsPro.Tests
{
    public class TechIncidentControllerTests
    {
        [Fact]
        public void Index_ModelIsATechnicianObject()
        {
            // arrange
            var controller = GetController();

            // act
            ViewResult result = (ViewResult)controller.Index();  // must cast bc action method has IActionResult return type
            var model = result.ViewData.Model as Technician;

            // assert
            Assert.IsType<Technician>(model);
        }

        [Fact]
        public void List_GET_ReturnsAViewResult()
        {
            // arrange
            var controller = GetController();

            // act
            var result = controller.List(1);

            // assert
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public void List_POST_ReturnsARedirectToActionResult()
        {
            // arrange
            var controller = GetController();

            var tempData = new Mock<ITempDataDictionary>();
            controller.TempData = tempData.Object;

            var technician = new Technician();

            // act
            var result = controller.List(technician);

            // assert
            Assert.IsType<RedirectToActionResult>(result);
        }

        // private helper methods
        //private IHttpContextAccessor GetMockHttpContextAccessor()
        //{
        //    var accessor = new Mock<IHttpContextAccessor>();
        //    var context = new DefaultHttpContext();
        //    var session = new Mock<ISession>();

        //    accessor.Setup(m => m.HttpContext).Returns(context);
        //    accessor.Setup(m => m.HttpContext.Session).Returns(session.Object);

        //    return accessor.Object;
        //}

        private TechIncidentController GetController()
        {
            var techRep = new Mock<IRepository<Technician>>();
            techRep.Setup(m => m.Get(It.IsAny<int>())).Returns(new Technician());
            techRep.Setup(m => m.List(It.IsAny<QueryOptions<Technician>>())).Returns(new List<Technician>());

            var incidentRep = new Mock<IRepository<Incident>>();
            incidentRep.Setup(m => m.Get(It.IsAny<int>())).Returns(new Incident());
            incidentRep.Setup(m => m.Get(It.IsAny<QueryOptions<Incident>>())).Returns(new Incident());
            incidentRep.Setup(m => m.List(It.IsAny<QueryOptions<Incident>>())).Returns(new List<Incident>());         

            var accessor = new Mock<IHttpContextAccessor>();
            var context = new DefaultHttpContext();
            var session = new Mock<ISession>();
            accessor.Setup(m => m.HttpContext).Returns(context);
            accessor.Setup(m => m.HttpContext!.Session).Returns(session.Object);

            var controller = new TechIncidentController(techRep.Object, incidentRep.Object, accessor.Object);
            return controller;
        }

        //private ISportsProUnit GetMockUnitOfWork()
        //{
        //    var irep = new Mock<IRepository<Incident>>();
        //    irep.Setup(m => m.Get(It.IsAny<int>())).Returns(new Incident());
        //    irep.Setup(m => m.Get(It.IsAny<QueryOptions<Incident>>())).Returns(new Incident());
        //    irep.Setup(m => m.List(It.IsAny<QueryOptions<Incident>>())).Returns(new List<Incident>());

        //    var trep = new Mock<IRepository<Technician>>();
        //    trep.Setup(m => m.Get(It.IsAny<int>())).Returns(new Technician());
        //    trep.Setup(m => m.List(It.IsAny<QueryOptions<Technician>>())).Returns(new List<Technician>());

        //    var unit = new Mock<ISportsProUnit>();
        //    unit.Setup(m => m.Incidents).Returns(irep.Object);
        //    unit.Setup(m => m.Technicians).Returns(trep.Object);

        //    return unit.Object;
        //}
    }
}
