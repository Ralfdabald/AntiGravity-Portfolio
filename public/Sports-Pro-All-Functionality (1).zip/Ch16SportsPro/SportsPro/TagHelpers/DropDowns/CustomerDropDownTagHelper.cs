﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using SportsPro.Models;

namespace SportsPro.TagHelpers
{
    [HtmlTargetElement(Attributes = "my-customers")]
    public class CustomerDropDownTagHelper : BaseDropDownTagHelper
    {
        private IRepository<Customer> data { get; set; }
        public CustomerDropDownTagHelper(IRepository<Customer> rep) => data = rep;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            string selectedValue = base.GetSelectedValue(context);

            // get list from database
            var customers = data.List(new QueryOptions<Customer> { OrderBy = c => c.FirstName });

            // add default option
            base.AddOption(output, "Select a customer...", "");

            // add rest of options 
            foreach (var customer in customers)
            {
                base.AddOption(output, customer.FullName, customer.CustomerID.ToString(), selectedValue);
            }

        }

    }
}
