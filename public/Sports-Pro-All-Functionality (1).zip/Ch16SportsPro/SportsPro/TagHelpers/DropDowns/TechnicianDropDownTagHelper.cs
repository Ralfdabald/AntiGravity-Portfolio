﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using SportsPro.Models;

namespace SportsPro.TagHelpers
{
    [HtmlTargetElement(Attributes = "my-technicians")]
    public class TechnicianDropDownTagHelper : BaseDropDownTagHelper
    {
        private IRepository<Technician> data { get; set; }
        public TechnicianDropDownTagHelper(IRepository<Technician> rep) => data = rep;

        public bool IncludeDefaultOption { get; set; } 

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            string selectedValue = base.GetSelectedValue(context);

            // get list from database
            var options = new QueryOptions<Technician> {
                OrderBy = t => t.Name
            };
            // skip unassigned default value if going to add a default option
            if (IncludeDefaultOption) 
                options.Where = t => t.TechnicianID > -1; 
            
            var technicians = data.List(options);

            // add options 
            if (IncludeDefaultOption) 
                base.AddOption(output, "Select a technician...", "");
            
            foreach (var technician in technicians)
            {
                base.AddOption(output, technician.Name, technician.TechnicianID.ToString(), selectedValue);
            }

        }

    }
}
