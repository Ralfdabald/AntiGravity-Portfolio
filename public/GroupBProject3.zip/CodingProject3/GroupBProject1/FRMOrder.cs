﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;
//AUTHOR:   Zoe Cruz, Cassandra Elizondo, Collin Fuchs, Josh High, Tyler Kwan
//COURSE:   ISTM 250.501
//FORM:  FRMOrder.cs
//PURPOSE: Create a form that takes user input of their personal information,
//   food order, and desired delivery method, then output the total (with tax)
//   that they are expected to pay for the order.
//INPUT:   Customer name, phone number, street address, subdivision, city, state,
//   zipcode, delviery method, delivery address (if needed), food type, bread
//   type, and the quantity of each food item.
//PROCESS: Clear is used to clear the form when the clear form button is clicked.
//   The order is validated if the user enters information into all appropraite
//   groupboxes, and enters a proper delviery address. If the order is validated,
//   then the form clears when the user processes order. Close is used to close
//   the form when the user clicks the button. Items are formatted and added to
//   the order list if the user filled out all parts of order information.
//OUTPUT:  Image of pizza or sandwich, order list of all added items with each
//   subtotal, and the order total after taxes.
//HONOR CODE: “On my honor, as an Aggie, I have neither given  
//   nor received unauthorized aid on this academic  
//   work.”
namespace GroupBProject1
{
    public partial class FRMOrder : Form
    {
        #region Global Lists, Arrays, & Variables
        //declare global list of items, food total, and food price
        List<double> dblItemsList = new List<double>();
        double dblItemTotal = 0;
        double dblFoodPrice = 0;

        //string with current product amounts
        decimal[] decProductAmounts = { 200m, 50m, 30m, 25m, 10m, 10m, 20m, 14m, 14m, 10m, 20m, 15m, 12m, 20m, 60m, 25m, 10m, 10m };

        // array that keeps track of product used throughout 
        decimal[] decTotalProductUsed = { 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m };
        
        // amount of product used for: H&S, T&P, BLT, Che, Pep, Sup
        decimal[,] decProductUsedPerItem = { { 1m, 1m, 1m, 3m, 3m, 3m },
                                      { 0.5m, 0.5m, 0.5m, 2m, 2m, 2m },
                                      { 0.03m, 0.03m, 0.03m, 0.5m, 0.5m, 0.5m },
                                      { 0.05m, 0.05m, 0.05m, 0.1m, 0.1m, 0.1m },
                                      { 0.1m, 0m, 0m, 0m, 0m, 0.1m },
                                      { 0m, 0.1m, 0m, 0m, 0m, 0.1m },
                                      { 0.1m, 0.1m, 0m, 0m, 0m, 0m },
                                      { 0.25m, 0.25m, 0.3m, 0m, 0m, 0m },
                                      { 0.25m, 0.25m, 0.3m, 0m, 0m, 0.3m },
                                      { 0m, 0m, 0.1m, 0m ,0m, 0.1m },
                                      { 0.02m, 0.02m, 0m, 0m, 0m, 0m },
                                      { 0.02m, 0.02m, 0.02m, 0m, 0m, 0m },
                                      { 0.02m, 0.02m, 0.02m, 0m, 0m, 0m },
                                      { 0m, 0m, 0m, 0m, 0.3m, 0.3m },
                                      { 0m, 0m, 0m, 1m, 1m, 1m },
                                      { 0m, 0m, 0m, 0.3m, 0.2m, 0.2m },
                                      { 0.01m, 0.01m, 0.01m, 0.02m, 0.02m, 0.02m },
                                      { 0.01m, 0.01m, 0.01m, 0.02m, 0.02m, 0.02m } };
        #endregion 
        public FRMOrder()
        {
            InitializeComponent();
        }
        #region Combo Box Processing
        /// <summary>
        /// when the form loads the food type options load into CBOFoodType  
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FRMOrder_Load(object sender, EventArgs e)
        {
            //loads food type options into the combo box
            CBOFoodType.Items.Add("Ham & Swiss Sandwich");
            CBOFoodType.Items.Add("Turkey & Provolone Sandwich");
            CBOFoodType.Items.Add("BLT Sandwich");
            CBOFoodType.Items.Add("Med. Cheese Pizza");
            CBOFoodType.Items.Add("Med. Pepperoni Pizza");
            CBOFoodType.Items.Add("Med. Supreme Pizza");
        }

        /// <summary>
        /// Bread types for pizza or sandwich load into the CBOBreadtype based on what the user clcks.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CBOFoodType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // if the user selects a pizza for the food type combo box then the bread type combo box will load the following
            if (CBOFoodType.SelectedIndex >= 3)
            {
                //user can enter quantity after food type is selected 
                TXTQuantity.ReadOnly = false;

                //adds picture of pizza
                PBOFoodImg.Image = Properties.Resources.pizza;
                PBOFoodImg.Visible = true;

                //bread types
                CBOBreadType.Items.Clear();
                CBOBreadType.Items.Add("Orginal");
                CBOBreadType.Items.Add("Pan");
                CBOBreadType.Items.Add("Thin");
                CBOBreadType.Items.Add("Wheat");
                CBOBreadType.SelectedIndex = -1;
                
                //sets price of food for pizzas
                dblFoodPrice = 9.5;
            }
            // if the user selects a sandwich for the food type combo box then the bread type combo box will load the following
            else if (CBOFoodType.SelectedIndex < 3)
            {
                //user can enter quantity after food type is selected 
                TXTQuantity.ReadOnly = false;

                //adds picture of sandwich
                PBOFoodImg.Image = Properties.Resources.deli;
                PBOFoodImg.Visible = true;

                //bread types
                CBOBreadType.Items.Clear();
                CBOBreadType.Items.Add("White");
                CBOBreadType.Items.Add("Pumpernickel");
                CBOBreadType.Items.Add("Rye");
                CBOBreadType.Items.Add("Sourdough");
                CBOBreadType.Items.Add("Multigrain");
                CBOBreadType.SelectedIndex = -1;
                
                //sets price of sandwiches
                dblFoodPrice = 5;
            }
        }
        #endregion

        #region Form Button Processing (Add Item, Process Order,& Close) 
        /// <summary>
        /// when the add item button is clicked, the ordered item will be shown in LBXOrder and the subtotal for each item will be calculated
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNAddItem_Click(object sender, EventArgs e)
        {
            try
            {
                //variable declaration
                int intQuantity = Convert.ToInt32(TXTQuantity.Text);
                string strFoodType = CBOFoodType.Text.ToString();
                string strBreadType = CBOBreadType.Text.ToString();
                double dblOrderTotal = 0;
                string strOrder = "";

                //checks if customer name is entered before subtotal is found
                if (IsPresent(TXTName.Text, TXTName.Tag.ToString()) != "")
                {
                    MessageBox.Show("Please enter customer name.", "Entry error");
                }
                //makes sure a food item is selected
                else if (CBOFoodType.SelectedIndex == -1)
                {
                    MessageBox.Show("Please choose a food item.", "Entry error");
                }
                //makes sure bread type is selected
                else if (CBOBreadType.SelectedIndex == -1)
                {
                    MessageBox.Show("Please choose a bread type.", "Entry error");
                }
                //makes sure quantity is greater than 0
                else if (intQuantity <= 0)
                {
                    MessageBox.Show("Please enter a quantity greater than zero.", "Quantity error");
                }
                else if (intQuantity > 0)
                {
                    //find price of users order
                    dblItemTotal = dblFoodPrice * intQuantity;
                    
                    //add users order to list
                    dblItemsList.Add(dblItemTotal);

                    //for loop to add all items together
                    foreach (var i in dblItemsList)
                    {
                        dblOrderTotal += i;
                    }

                    //finds and outputs order total after taxes
                    dblOrderTotal += (dblOrderTotal * .0825);
                    TXTOrderTotal.Text = dblOrderTotal.ToString("c");

                    //outputs proper format of the ordered item to list box
                    strOrder = strBreadType + " " + strFoodType + ", " + intQuantity + "@" + dblFoodPrice.ToString("c") + ", " + "total: " + dblItemTotal.ToString("c");
                    LBXFinalOrder.Items.Add(strOrder);

                    //add amount of product used times quantity to total product used
                    //sets what food type the user chose to a variable
                    int intFoodType = CBOFoodType.SelectedIndex;
                    for (int i = 0; i < decProductAmounts.Length; i++)
                    {
                        //sets each element of an empty array to the product used times how much the user ordered of the food item
                        decTotalProductUsed[i] += decProductUsedPerItem[i, intFoodType] * intQuantity;
                    }

                    //resets quantity, bread type, food type, and image
                    TXTQuantity.Text = "";
                    CBOFoodType.SelectedIndex = -1;
                    CBOBreadType.Items.Clear();
                    TXTQuantity.ReadOnly = true;
                    PBOFoodImg.Visible = false;
                }
            }
            catch
            {
                Validator.IsInt32(TXTQuantity);

            }

        }
        /// <summary>
        /// outputs order total after taxes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// 
        private void BTNFinishOrder_Click(object sender, EventArgs e)
        {
            try
            {
                //checks to see if user ordered anything
                if (LBXFinalOrder.Items.Count != 0)
                {
                    //validates user input
                    if (IsValidData() && IsValidDeliveryAddress())
                    { 
                        MessageBox.Show("Thanks for your order!");
                        
                        //subtract product used for order from the product amounts array
                        for (int j = 0; j < decProductAmounts.Length; j++)
                        {
                            decProductAmounts[j] -= decTotalProductUsed[j];
                        }

                        ////clears customer information
                        //TXTName.Clear();
                        //TXTPhoneNumber.Clear();

                        ////clears address information
                        //TXTState.Clear();
                        //TXTOrderTotal.Clear();
                        //TXTStreetAddress.Clear();
                        //TXTSubdivision.Clear();
                        //TXTCity.Clear();
                        //TXTZipCode.Clear();
                        //CHKDeliveryAddress.Checked = false;

                        ////clears delivery address
                        //TXTDeliveryState.Clear();
                        //TXTDeliveryStreetAddress.Clear();
                        //TXTDeliverySubdivision.Clear();
                        //TXTDeliveryCity.Clear();
                        //TXTDeliveryZipCode.Clear();

                        //order information and list textbox
                        RDODeliver.Checked = true;
                        TXTQuantity.Clear();
                        TXTQuantity.ReadOnly = true;
                        CBOFoodType.SelectedIndex = -1;
                        CBOBreadType.Items.Clear();
                        PBOFoodImg.Visible = false;
                        LBXFinalOrder.Items.Clear();
                        TXTOrderTotal.Clear();
                        dblItemsList.Clear();

                        //clears array of product used
                        Array.Clear(decTotalProductUsed, 0, decTotalProductUsed.Length);
                    }
                }
                else 
                {
                    //makes sure user ordered food items
                    MessageBox.Show("Please add your food order.");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Please make sure all entries are filled.", "Entry Error");
            }
        }
        /// <summary>
        /// form closes when user clicks close button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion

        #region Radio Button Processing
        /// <summary>
        /// enables delivery address groupbox if deliver is checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RDODeliver_CheckedChanged(object sender, EventArgs e)
        {
            if (RDOCarryOut.Checked)
            {
                //does not allow user to type in delivery address if carry out is checked
                GBXDeliveryAddress.Enabled = false;
            }
            else if (RDODeliver.Checked)
            {
                GBXDeliveryAddress.Enabled = true;
            }
        }
        #endregion

        #region CheckBox Processing 
        /// <summary>
        /// copies address info to delivery address if checkbox is checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CHKDeliveryAddress_CheckedChanged(object sender, EventArgs e)
        {
            if (CHKDeliveryAddress.Checked)
            {
                TXTDeliveryStreetAddress.Text = TXTStreetAddress.Text;
                TXTDeliverySubdivision.Text = TXTSubdivision.Text;
                TXTDeliveryCity.Text = TXTCity.Text;
                TXTDeliveryState.Text = TXTState.Text;
                TXTDeliveryZipCode.Text = TXTZipCode.Text;
            }
            else // if the delivery address checkbox is unchecked, the devilvery address info will clear
            {
                TXTDeliveryStreetAddress.Text = "";
                TXTDeliverySubdivision.Text = "";
                TXTDeliveryCity.Text = "";
                TXTDeliveryState.Text = "";
                TXTDeliveryZipCode.Text = "";
            }
        }
        #endregion

        #region Validation 
        /// <summary>
        /// validate user data
        /// </summary>
        /// <returns></returns>
        private bool IsValidData()
        {
            //makes sure that contact info and address info groupboxes have user input
            return Validator.IsPresent(TXTName) &&
               Validator.IsPresent(TXTPhoneNumber) &&
               Validator.IsPresent(TXTStreetAddress) &&
               Validator.IsPresent(TXTSubdivision) &&
               Validator.IsPresent(TXTState) &&
               Validator.IsPresent(TXTCity) &&
               Validator.IsPresent(TXTZipCode);
        }
        private bool IsValidDeliveryAddress()
        {
            if (RDODeliver.Checked)
            {
                //trims trailing spaces before and after user input
                string strDeliveryCity = TXTDeliveryCity.Text.Trim();
                string strDeliveryState = TXTDeliveryState.Text.Trim();
                //makes user input all lowercase
                strDeliveryCity = strDeliveryCity.ToLower();
                strDeliveryState = strDeliveryState.ToLower();

                //if the user did not input college station or bryan as the city, and tx or texas as the state then it is not a valid delivery address
                if ((strDeliveryCity != "bryan") && (strDeliveryCity != "college station"))
                {
                    MessageBox.Show("Delivery address must be in either College Station or Bryan\n");
                    return false;
                }
                else if ((strDeliveryState != "texas") && (strDeliveryState != "tx"))
                {
                    MessageBox.Show("Delivery address must be inside of Texas\n");
                    return false;
                }
                else
                {
                    //validates delivery address if user city/state is correct
                    return Validator.IsPresent(TXTDeliveryStreetAddress) &&
                     Validator.IsPresent(TXTDeliverySubdivision) &&
                     Validator.IsPresent(TXTDeliveryCity) &&
                     Validator.IsPresent(TXTDeliveryState) &&
                     Validator.IsPresent(TXTDeliveryZipCode);

                }
            }
            else
            {
                return true;
            }
        }
        /// <summary>
        /// checks if user inputted info for that textbox
        /// </summary>
        /// <param name="strTestValue"></param>
        /// <param name="strDescription"></param>
        /// <returns></returns>
        private string IsPresent(string strTestValue, string strDescription)
        {
            string strMessage = "";

            //checks if string is empty, and formats error message if it is
            if (strTestValue == "")
            {
                strMessage = strDescription + " is a required field.\n";
            }
            return strMessage;
        }
        #endregion

        #region Form Button Processing (Clear Form) 
        /// <summary>
        /// clears the entire form when the user clicks clear form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNClearForm_Click(object sender, EventArgs e)
        {
            //clears customer information
            TXTName.Clear();
            TXTPhoneNumber.Clear();
            
            //clears address information
            TXTState.Clear();
            TXTOrderTotal.Clear();
            TXTStreetAddress.Clear();
            TXTSubdivision.Clear();
            TXTCity.Clear();
            TXTZipCode.Clear();
            CHKDeliveryAddress.Checked = false;

            //clears delivery address
            TXTDeliveryState.Clear();
            TXTDeliveryStreetAddress.Clear();
            TXTDeliverySubdivision.Clear();
            TXTDeliveryCity.Clear();
            TXTDeliveryZipCode.Clear();
            
            //order information and list textbox
            RDODeliver.Checked = true;
            TXTQuantity.Clear();
            TXTQuantity.ReadOnly = true;
            CBOBreadType.Items.Clear();
            CBOFoodType.SelectedIndex = -1;
            PBOFoodImg.Visible = false;
            LBXFinalOrder.Items.Clear();
            TXTOrderTotal.Clear();
            dblItemsList.Clear();

            //clears array of product used
            Array.Clear(decTotalProductUsed, 0, decTotalProductUsed.Length);
        }
        #endregion 

        #region When address is also the delivery address 
        /// <summary>
        /// changes the delivery street address if regular street address is changed and delivery checkbox is checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TXTStreetAddress_TextChanged(object sender, EventArgs e)
        {
            if(CHKDeliveryAddress.Checked)
            {
                TXTDeliveryStreetAddress.Text = TXTStreetAddress.Text;
            }
        }
        /// <summary>
        /// changes the delivery subdivision if regular subdivision is changed and delivery checkbox is checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TXTSubdivision_TextChanged(object sender, EventArgs e)
        {
            if (CHKDeliveryAddress.Checked)
            {
                TXTDeliverySubdivision.Text = TXTSubdivision.Text;
            }
        }
        /// <summary>
        /// changes the delivery city if regular city is changed and delivery checkbox is checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TXTCity_TextChanged(object sender, EventArgs e)
        {
            if (CHKDeliveryAddress.Checked)
            {
                TXTDeliveryCity.Text = TXTCity.Text;
            }
        }
        /// <summary>
        /// changes the delivery state if regular street address is changed and delivery state is checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TXTState_TextChanged(object sender, EventArgs e)
        {
            if (CHKDeliveryAddress.Checked)
            {
                TXTDeliveryState.Text = TXTState.Text;
            }
        }
        /// <summary>
        /// changes the delivery zipcode if regular zipcode is changed and delivery checkbox is checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TXTZipCode_TextChanged(object sender, EventArgs e)
        {
            if (CHKDeliveryAddress.Checked)
            {
                TXTDeliveryZipCode.Text = TXTZipCode.Text;
            }
        }
        #endregion 

        /// <summary>
        /// displays the inventory form with the updated inventory after a user processes their order
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void BTNCheckInventory_Click(object sender, EventArgs e)
        {
            FRMInventory newInventoryForm = new FRMInventory();

            //sends the array to the inventory form
            newInventoryForm.ShowingArray(decProductAmounts);
            
            //displays array
            newInventoryForm.ShowDialog();
        }

        /// <summary>
        /// displays the vendor form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BTNVendors_Click(object sender, EventArgs e)
        {
            FRMVendor newVendorForm = new FRMVendor();
            //displays Vendor form
            newVendorForm.ShowDialog();
        }
    }
}
