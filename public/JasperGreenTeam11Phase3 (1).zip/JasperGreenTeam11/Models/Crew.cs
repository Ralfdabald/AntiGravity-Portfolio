﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: Crew.cs 
//PURPOSE: Defines the Crew model used to represent a landscaping crew composed of a foreman and two members.
//INITIALIZE: This class must be included in the data model and registered in the JasperGreenContext to participate in Entity Framework Core operations.
//INPUT: Data related to the crew, including crew name, assigned employees (foreman, member1, member2), and associated properties.
//PROCESS: Provides a structured representation of a crew with relationships to employees and properties. 
// Enables navigation and data binding in Razor views and controller logic.
//OUTPUT: Used throughout the application to create, edit, list, and delete crew data, and link crews to properties.
//TERMINATE: Managed through Entity Framework Core lifecycle, disposed of automatically when context is closed.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JasperGreenTeam11.Models
{
    public class Crew
    {
        public int CrewId { get; set; } // Primary Key

        [Required]
        [MaxLength(100)]
        public string CrewName { get; set; } = string.Empty;

        // Foreign Keys for employee roles
        public int? CrewForemanID { get; set; }
        public int? CrewMember1ID { get; set; }
        public int? CrewMember2ID { get; set; }

        // Navigation properties to individual employees
        [ForeignKey(nameof(CrewForemanID))]
        [ValidateNever]
        public Employee? CrewForeman { get; set; }

        [ForeignKey(nameof(CrewMember1ID))]
        [ValidateNever]
        public Employee? CrewMember1 { get; set; }

        [ForeignKey(nameof(CrewMember2ID))]
        [ValidateNever]
        public Employee? CrewMember2 { get; set; }

        // Navigation Property: A crew has many employees (if needed)
        public ICollection<Employee>? Employees { get; set; }
        public ICollection<Property>? Properties { get; set; }
    }
}
