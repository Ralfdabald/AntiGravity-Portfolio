﻿
namespace GroupBProject1
{
    partial class FRMOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RDOCarryOut = new System.Windows.Forms.RadioButton();
            this.GBXCustomerInformation = new System.Windows.Forms.GroupBox();
            this.TXTPhoneNumber = new System.Windows.Forms.TextBox();
            this.TXTName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.GBXAddressInformation = new System.Windows.Forms.GroupBox();
            this.CHKDeliveryAddress = new System.Windows.Forms.CheckBox();
            this.TXTZipCode = new System.Windows.Forms.TextBox();
            this.TXTState = new System.Windows.Forms.TextBox();
            this.TXTCity = new System.Windows.Forms.TextBox();
            this.TXTSubdivision = new System.Windows.Forms.TextBox();
            this.TXTStreetAddress = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.GBXOrderInformation = new System.Windows.Forms.GroupBox();
            this.PBOFoodImg = new System.Windows.Forms.PictureBox();
            this.BTNAddItem = new System.Windows.Forms.Button();
            this.TXTQuantity = new System.Windows.Forms.TextBox();
            this.CBOBreadType = new System.Windows.Forms.ComboBox();
            this.CBOFoodType = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.RDODeliver = new System.Windows.Forms.RadioButton();
            this.BTNClearForm = new System.Windows.Forms.Button();
            this.GBXDeliveryAddress = new System.Windows.Forms.GroupBox();
            this.TXTDeliveryZipCode = new System.Windows.Forms.TextBox();
            this.TXTDeliveryState = new System.Windows.Forms.TextBox();
            this.TXTDeliveryCity = new System.Windows.Forms.TextBox();
            this.TXTDeliverySubdivision = new System.Windows.Forms.TextBox();
            this.TXTDeliveryStreetAddress = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.LBXFinalOrder = new System.Windows.Forms.ListBox();
            this.BTNProcessOrder = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.TXTOrderTotal = new System.Windows.Forms.TextBox();
            this.BTNClose = new System.Windows.Forms.Button();
            this.BTNCheckInventory = new System.Windows.Forms.Button();
            this.BTNVendors = new System.Windows.Forms.Button();
            this.GBXCustomerInformation.SuspendLayout();
            this.GBXAddressInformation.SuspendLayout();
            this.GBXOrderInformation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBOFoodImg)).BeginInit();
            this.GBXDeliveryAddress.SuspendLayout();
            this.SuspendLayout();
            // 
            // RDOCarryOut
            // 
            this.RDOCarryOut.AutoSize = true;
            this.RDOCarryOut.Location = new System.Drawing.Point(136, 30);
            this.RDOCarryOut.Margin = new System.Windows.Forms.Padding(4);
            this.RDOCarryOut.Name = "RDOCarryOut";
            this.RDOCarryOut.Size = new System.Drawing.Size(83, 20);
            this.RDOCarryOut.TabIndex = 0;
            this.RDOCarryOut.Text = "Carry Out";
            this.RDOCarryOut.UseVisualStyleBackColor = true;
            // 
            // GBXCustomerInformation
            // 
            this.GBXCustomerInformation.Controls.Add(this.TXTPhoneNumber);
            this.GBXCustomerInformation.Controls.Add(this.TXTName);
            this.GBXCustomerInformation.Controls.Add(this.label2);
            this.GBXCustomerInformation.Controls.Add(this.label1);
            this.GBXCustomerInformation.Location = new System.Drawing.Point(39, 15);
            this.GBXCustomerInformation.Margin = new System.Windows.Forms.Padding(4);
            this.GBXCustomerInformation.Name = "GBXCustomerInformation";
            this.GBXCustomerInformation.Padding = new System.Windows.Forms.Padding(4);
            this.GBXCustomerInformation.Size = new System.Drawing.Size(371, 133);
            this.GBXCustomerInformation.TabIndex = 1;
            this.GBXCustomerInformation.TabStop = false;
            this.GBXCustomerInformation.Text = "Customer Information";
            // 
            // TXTPhoneNumber
            // 
            this.TXTPhoneNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTPhoneNumber.Location = new System.Drawing.Point(129, 84);
            this.TXTPhoneNumber.Margin = new System.Windows.Forms.Padding(4);
            this.TXTPhoneNumber.Name = "TXTPhoneNumber";
            this.TXTPhoneNumber.Size = new System.Drawing.Size(173, 22);
            this.TXTPhoneNumber.TabIndex = 3;
            this.TXTPhoneNumber.Tag = "Phone Number";
            this.TXTPhoneNumber.Text = "(123) 456-7890";
            // 
            // TXTName
            // 
            this.TXTName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTName.Location = new System.Drawing.Point(129, 33);
            this.TXTName.Margin = new System.Windows.Forms.Padding(4);
            this.TXTName.Name = "TXTName";
            this.TXTName.Size = new System.Drawing.Size(173, 22);
            this.TXTName.TabIndex = 2;
            this.TXTName.Tag = "Name";
            this.TXTName.Text = "John Smith";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 84);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(103, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Phone Number: ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 36);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // GBXAddressInformation
            // 
            this.GBXAddressInformation.Controls.Add(this.CHKDeliveryAddress);
            this.GBXAddressInformation.Controls.Add(this.TXTZipCode);
            this.GBXAddressInformation.Controls.Add(this.TXTState);
            this.GBXAddressInformation.Controls.Add(this.TXTCity);
            this.GBXAddressInformation.Controls.Add(this.TXTSubdivision);
            this.GBXAddressInformation.Controls.Add(this.TXTStreetAddress);
            this.GBXAddressInformation.Controls.Add(this.label7);
            this.GBXAddressInformation.Controls.Add(this.label6);
            this.GBXAddressInformation.Controls.Add(this.label5);
            this.GBXAddressInformation.Controls.Add(this.label4);
            this.GBXAddressInformation.Controls.Add(this.label3);
            this.GBXAddressInformation.Location = new System.Drawing.Point(39, 178);
            this.GBXAddressInformation.Margin = new System.Windows.Forms.Padding(4);
            this.GBXAddressInformation.Name = "GBXAddressInformation";
            this.GBXAddressInformation.Padding = new System.Windows.Forms.Padding(4);
            this.GBXAddressInformation.Size = new System.Drawing.Size(371, 215);
            this.GBXAddressInformation.TabIndex = 2;
            this.GBXAddressInformation.TabStop = false;
            this.GBXAddressInformation.Text = "Address Information";
            // 
            // CHKDeliveryAddress
            // 
            this.CHKDeliveryAddress.AutoSize = true;
            this.CHKDeliveryAddress.Location = new System.Drawing.Point(7, 188);
            this.CHKDeliveryAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CHKDeliveryAddress.Name = "CHKDeliveryAddress";
            this.CHKDeliveryAddress.Size = new System.Drawing.Size(133, 20);
            this.CHKDeliveryAddress.TabIndex = 11;
            this.CHKDeliveryAddress.Text = "Delivery Address";
            this.CHKDeliveryAddress.UseVisualStyleBackColor = true;
            this.CHKDeliveryAddress.CheckedChanged += new System.EventHandler(this.CHKDeliveryAddress_CheckedChanged);
            // 
            // TXTZipCode
            // 
            this.TXTZipCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTZipCode.Location = new System.Drawing.Point(129, 153);
            this.TXTZipCode.Margin = new System.Windows.Forms.Padding(4);
            this.TXTZipCode.Name = "TXTZipCode";
            this.TXTZipCode.Size = new System.Drawing.Size(173, 22);
            this.TXTZipCode.TabIndex = 10;
            this.TXTZipCode.Tag = "Zip Code";
            this.TXTZipCode.Text = "77840";
            this.TXTZipCode.TextChanged += new System.EventHandler(this.TXTZipCode_TextChanged);
            // 
            // TXTState
            // 
            this.TXTState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTState.Location = new System.Drawing.Point(129, 121);
            this.TXTState.Margin = new System.Windows.Forms.Padding(4);
            this.TXTState.Name = "TXTState";
            this.TXTState.Size = new System.Drawing.Size(173, 22);
            this.TXTState.TabIndex = 9;
            this.TXTState.Tag = "State";
            this.TXTState.Text = "TX";
            this.TXTState.TextChanged += new System.EventHandler(this.TXTState_TextChanged);
            // 
            // TXTCity
            // 
            this.TXTCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTCity.Location = new System.Drawing.Point(129, 89);
            this.TXTCity.Margin = new System.Windows.Forms.Padding(4);
            this.TXTCity.Name = "TXTCity";
            this.TXTCity.Size = new System.Drawing.Size(173, 22);
            this.TXTCity.TabIndex = 8;
            this.TXTCity.Tag = "City";
            this.TXTCity.Text = "College Station";
            this.TXTCity.TextChanged += new System.EventHandler(this.TXTCity_TextChanged);
            // 
            // TXTSubdivision
            // 
            this.TXTSubdivision.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTSubdivision.Location = new System.Drawing.Point(129, 57);
            this.TXTSubdivision.Margin = new System.Windows.Forms.Padding(4);
            this.TXTSubdivision.Name = "TXTSubdivision";
            this.TXTSubdivision.Size = new System.Drawing.Size(173, 22);
            this.TXTSubdivision.TabIndex = 7;
            this.TXTSubdivision.Tag = "Subdivision";
            this.TXTSubdivision.Text = "Drive";
            this.TXTSubdivision.TextChanged += new System.EventHandler(this.TXTSubdivision_TextChanged);
            // 
            // TXTStreetAddress
            // 
            this.TXTStreetAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTStreetAddress.Location = new System.Drawing.Point(129, 25);
            this.TXTStreetAddress.Margin = new System.Windows.Forms.Padding(4);
            this.TXTStreetAddress.Name = "TXTStreetAddress";
            this.TXTStreetAddress.Size = new System.Drawing.Size(173, 22);
            this.TXTStreetAddress.TabIndex = 6;
            this.TXTStreetAddress.Tag = "Street Address";
            this.TXTStreetAddress.Text = "123 Main Street";
            this.TXTStreetAddress.TextChanged += new System.EventHandler(this.TXTStreetAddress_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 153);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 16);
            this.label7.TabIndex = 4;
            this.label7.Text = "Zip Code:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 121);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "State:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 90);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "City: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 59);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "Subdivision: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 28);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Street Address: ";
            // 
            // GBXOrderInformation
            // 
            this.GBXOrderInformation.Controls.Add(this.PBOFoodImg);
            this.GBXOrderInformation.Controls.Add(this.BTNAddItem);
            this.GBXOrderInformation.Controls.Add(this.TXTQuantity);
            this.GBXOrderInformation.Controls.Add(this.CBOBreadType);
            this.GBXOrderInformation.Controls.Add(this.CBOFoodType);
            this.GBXOrderInformation.Controls.Add(this.label11);
            this.GBXOrderInformation.Controls.Add(this.label10);
            this.GBXOrderInformation.Controls.Add(this.label9);
            this.GBXOrderInformation.Controls.Add(this.label8);
            this.GBXOrderInformation.Controls.Add(this.RDODeliver);
            this.GBXOrderInformation.Controls.Add(this.RDOCarryOut);
            this.GBXOrderInformation.Location = new System.Drawing.Point(451, 15);
            this.GBXOrderInformation.Margin = new System.Windows.Forms.Padding(4);
            this.GBXOrderInformation.Name = "GBXOrderInformation";
            this.GBXOrderInformation.Padding = new System.Windows.Forms.Padding(4);
            this.GBXOrderInformation.Size = new System.Drawing.Size(524, 266);
            this.GBXOrderInformation.TabIndex = 3;
            this.GBXOrderInformation.TabStop = false;
            this.GBXOrderInformation.Text = "Order Information";
            // 
            // PBOFoodImg
            // 
            this.PBOFoodImg.BackColor = System.Drawing.SystemColors.Control;
            this.PBOFoodImg.Location = new System.Drawing.Point(348, 70);
            this.PBOFoodImg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PBOFoodImg.Name = "PBOFoodImg";
            this.PBOFoodImg.Size = new System.Drawing.Size(155, 98);
            this.PBOFoodImg.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PBOFoodImg.TabIndex = 13;
            this.PBOFoodImg.TabStop = false;
            // 
            // BTNAddItem
            // 
            this.BTNAddItem.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNAddItem.Location = new System.Drawing.Point(163, 214);
            this.BTNAddItem.Margin = new System.Windows.Forms.Padding(4);
            this.BTNAddItem.Name = "BTNAddItem";
            this.BTNAddItem.Size = new System.Drawing.Size(100, 28);
            this.BTNAddItem.TabIndex = 9;
            this.BTNAddItem.Text = "Add Item(s)";
            this.BTNAddItem.UseVisualStyleBackColor = false;
            this.BTNAddItem.Click += new System.EventHandler(this.BTNAddItem_Click);
            // 
            // TXTQuantity
            // 
            this.TXTQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTQuantity.Location = new System.Drawing.Point(101, 154);
            this.TXTQuantity.Margin = new System.Windows.Forms.Padding(4);
            this.TXTQuantity.Name = "TXTQuantity";
            this.TXTQuantity.ReadOnly = true;
            this.TXTQuantity.Size = new System.Drawing.Size(133, 22);
            this.TXTQuantity.TabIndex = 8;
            this.TXTQuantity.Tag = "Quantity";
            // 
            // CBOBreadType
            // 
            this.CBOBreadType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBOBreadType.FormattingEnabled = true;
            this.CBOBreadType.Location = new System.Drawing.Point(101, 110);
            this.CBOBreadType.Margin = new System.Windows.Forms.Padding(4);
            this.CBOBreadType.Name = "CBOBreadType";
            this.CBOBreadType.Size = new System.Drawing.Size(225, 24);
            this.CBOBreadType.TabIndex = 7;
            // 
            // CBOFoodType
            // 
            this.CBOFoodType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBOFoodType.FormattingEnabled = true;
            this.CBOFoodType.Location = new System.Drawing.Point(101, 70);
            this.CBOFoodType.Margin = new System.Windows.Forms.Padding(4);
            this.CBOFoodType.Name = "CBOFoodType";
            this.CBOFoodType.Size = new System.Drawing.Size(225, 24);
            this.CBOFoodType.TabIndex = 6;
            this.CBOFoodType.SelectedIndexChanged += new System.EventHandler(this.CBOFoodType_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(8, 153);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 16);
            this.label11.TabIndex = 5;
            this.label11.Text = "Quantity: ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(8, 112);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 16);
            this.label10.TabIndex = 4;
            this.label10.Text = "Bread Type: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(8, 71);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 16);
            this.label9.TabIndex = 3;
            this.label9.Text = "Food Type: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 32);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 16);
            this.label8.TabIndex = 2;
            this.label8.Text = "Delivery Method: ";
            // 
            // RDODeliver
            // 
            this.RDODeliver.AutoSize = true;
            this.RDODeliver.Checked = true;
            this.RDODeliver.Location = new System.Drawing.Point(249, 30);
            this.RDODeliver.Margin = new System.Windows.Forms.Padding(4);
            this.RDODeliver.Name = "RDODeliver";
            this.RDODeliver.Size = new System.Drawing.Size(71, 20);
            this.RDODeliver.TabIndex = 1;
            this.RDODeliver.TabStop = true;
            this.RDODeliver.Text = "Deliver";
            this.RDODeliver.UseVisualStyleBackColor = true;
            this.RDODeliver.CheckedChanged += new System.EventHandler(this.RDODeliver_CheckedChanged);
            // 
            // BTNClearForm
            // 
            this.BTNClearForm.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNClearForm.Location = new System.Drawing.Point(477, 652);
            this.BTNClearForm.Margin = new System.Windows.Forms.Padding(4);
            this.BTNClearForm.Name = "BTNClearForm";
            this.BTNClearForm.Size = new System.Drawing.Size(125, 30);
            this.BTNClearForm.TabIndex = 10;
            this.BTNClearForm.Text = "Clear Form";
            this.BTNClearForm.UseVisualStyleBackColor = false;
            this.BTNClearForm.Click += new System.EventHandler(this.BTNClearForm_Click);
            // 
            // GBXDeliveryAddress
            // 
            this.GBXDeliveryAddress.Controls.Add(this.TXTDeliveryZipCode);
            this.GBXDeliveryAddress.Controls.Add(this.TXTDeliveryState);
            this.GBXDeliveryAddress.Controls.Add(this.TXTDeliveryCity);
            this.GBXDeliveryAddress.Controls.Add(this.TXTDeliverySubdivision);
            this.GBXDeliveryAddress.Controls.Add(this.TXTDeliveryStreetAddress);
            this.GBXDeliveryAddress.Controls.Add(this.label16);
            this.GBXDeliveryAddress.Controls.Add(this.label15);
            this.GBXDeliveryAddress.Controls.Add(this.label14);
            this.GBXDeliveryAddress.Controls.Add(this.label13);
            this.GBXDeliveryAddress.Controls.Add(this.label12);
            this.GBXDeliveryAddress.Location = new System.Drawing.Point(39, 431);
            this.GBXDeliveryAddress.Margin = new System.Windows.Forms.Padding(4);
            this.GBXDeliveryAddress.Name = "GBXDeliveryAddress";
            this.GBXDeliveryAddress.Padding = new System.Windows.Forms.Padding(4);
            this.GBXDeliveryAddress.Size = new System.Drawing.Size(371, 249);
            this.GBXDeliveryAddress.TabIndex = 4;
            this.GBXDeliveryAddress.TabStop = false;
            this.GBXDeliveryAddress.Text = "Delivery Address";
            // 
            // TXTDeliveryZipCode
            // 
            this.TXTDeliveryZipCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTDeliveryZipCode.Location = new System.Drawing.Point(129, 180);
            this.TXTDeliveryZipCode.Margin = new System.Windows.Forms.Padding(4);
            this.TXTDeliveryZipCode.Name = "TXTDeliveryZipCode";
            this.TXTDeliveryZipCode.Size = new System.Drawing.Size(173, 22);
            this.TXTDeliveryZipCode.TabIndex = 9;
            this.TXTDeliveryZipCode.Tag = "Delivery Zip Code";
            // 
            // TXTDeliveryState
            // 
            this.TXTDeliveryState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTDeliveryState.Location = new System.Drawing.Point(129, 144);
            this.TXTDeliveryState.Margin = new System.Windows.Forms.Padding(4);
            this.TXTDeliveryState.Name = "TXTDeliveryState";
            this.TXTDeliveryState.Size = new System.Drawing.Size(173, 22);
            this.TXTDeliveryState.TabIndex = 8;
            this.TXTDeliveryState.Tag = "Delivery State";
            // 
            // TXTDeliveryCity
            // 
            this.TXTDeliveryCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTDeliveryCity.Location = new System.Drawing.Point(129, 108);
            this.TXTDeliveryCity.Margin = new System.Windows.Forms.Padding(4);
            this.TXTDeliveryCity.Name = "TXTDeliveryCity";
            this.TXTDeliveryCity.Size = new System.Drawing.Size(173, 22);
            this.TXTDeliveryCity.TabIndex = 7;
            this.TXTDeliveryCity.Tag = "Delivery City";
            // 
            // TXTDeliverySubdivision
            // 
            this.TXTDeliverySubdivision.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTDeliverySubdivision.Location = new System.Drawing.Point(129, 71);
            this.TXTDeliverySubdivision.Margin = new System.Windows.Forms.Padding(4);
            this.TXTDeliverySubdivision.Name = "TXTDeliverySubdivision";
            this.TXTDeliverySubdivision.Size = new System.Drawing.Size(173, 22);
            this.TXTDeliverySubdivision.TabIndex = 6;
            this.TXTDeliverySubdivision.Tag = "Delivery Subdivison";
            // 
            // TXTDeliveryStreetAddress
            // 
            this.TXTDeliveryStreetAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTDeliveryStreetAddress.Location = new System.Drawing.Point(129, 36);
            this.TXTDeliveryStreetAddress.Margin = new System.Windows.Forms.Padding(4);
            this.TXTDeliveryStreetAddress.Name = "TXTDeliveryStreetAddress";
            this.TXTDeliveryStreetAddress.Size = new System.Drawing.Size(173, 22);
            this.TXTDeliveryStreetAddress.TabIndex = 5;
            this.TXTDeliveryStreetAddress.Tag = "Delivery Street Address";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 183);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 16);
            this.label16.TabIndex = 4;
            this.label16.Text = "Zip Code: ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(16, 146);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 16);
            this.label15.TabIndex = 3;
            this.label15.Text = "State:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 111);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(32, 16);
            this.label14.TabIndex = 2;
            this.label14.Text = "City:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(16, 75);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 16);
            this.label13.TabIndex = 1;
            this.label13.Text = "Subdivision:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 39);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "Street Address:";
            // 
            // LBXFinalOrder
            // 
            this.LBXFinalOrder.FormattingEnabled = true;
            this.LBXFinalOrder.ItemHeight = 16;
            this.LBXFinalOrder.Location = new System.Drawing.Point(451, 294);
            this.LBXFinalOrder.Margin = new System.Windows.Forms.Padding(4);
            this.LBXFinalOrder.Name = "LBXFinalOrder";
            this.LBXFinalOrder.Size = new System.Drawing.Size(524, 292);
            this.LBXFinalOrder.TabIndex = 5;
            // 
            // BTNProcessOrder
            // 
            this.BTNProcessOrder.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNProcessOrder.Location = new System.Drawing.Point(653, 652);
            this.BTNProcessOrder.Margin = new System.Windows.Forms.Padding(4);
            this.BTNProcessOrder.Name = "BTNProcessOrder";
            this.BTNProcessOrder.Size = new System.Drawing.Size(125, 30);
            this.BTNProcessOrder.TabIndex = 6;
            this.BTNProcessOrder.Text = "Process Order";
            this.BTNProcessOrder.UseVisualStyleBackColor = false;
            this.BTNProcessOrder.Click += new System.EventHandler(this.BTNFinishOrder_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(579, 613);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(81, 16);
            this.label17.TabIndex = 7;
            this.label17.Text = "Order Total: ";
            // 
            // TXTOrderTotal
            // 
            this.TXTOrderTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TXTOrderTotal.Location = new System.Drawing.Point(673, 609);
            this.TXTOrderTotal.Margin = new System.Windows.Forms.Padding(4);
            this.TXTOrderTotal.Name = "TXTOrderTotal";
            this.TXTOrderTotal.ReadOnly = true;
            this.TXTOrderTotal.Size = new System.Drawing.Size(189, 22);
            this.TXTOrderTotal.TabIndex = 8;
            // 
            // BTNClose
            // 
            this.BTNClose.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNClose.Location = new System.Drawing.Point(829, 652);
            this.BTNClose.Margin = new System.Windows.Forms.Padding(4);
            this.BTNClose.Name = "BTNClose";
            this.BTNClose.Size = new System.Drawing.Size(125, 30);
            this.BTNClose.TabIndex = 9;
            this.BTNClose.Text = "Close";
            this.BTNClose.UseVisualStyleBackColor = false;
            this.BTNClose.Click += new System.EventHandler(this.BTNClose_Click);
            // 
            // BTNCheckInventory
            // 
            this.BTNCheckInventory.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNCheckInventory.Location = new System.Drawing.Point(552, 697);
            this.BTNCheckInventory.Margin = new System.Windows.Forms.Padding(4);
            this.BTNCheckInventory.Name = "BTNCheckInventory";
            this.BTNCheckInventory.Size = new System.Drawing.Size(125, 30);
            this.BTNCheckInventory.TabIndex = 11;
            this.BTNCheckInventory.Text = "Check Inventory";
            this.BTNCheckInventory.UseVisualStyleBackColor = false;
            this.BTNCheckInventory.Click += new System.EventHandler(this.BTNCheckInventory_Click);
            // 
            // BTNVendors
            // 
            this.BTNVendors.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BTNVendors.Location = new System.Drawing.Point(742, 697);
            this.BTNVendors.Margin = new System.Windows.Forms.Padding(4);
            this.BTNVendors.Name = "BTNVendors";
            this.BTNVendors.Size = new System.Drawing.Size(125, 30);
            this.BTNVendors.TabIndex = 12;
            this.BTNVendors.Text = "Vendors";
            this.BTNVendors.UseVisualStyleBackColor = false;
            this.BTNVendors.Click += new System.EventHandler(this.BTNVendors_Click);
            // 
            // FRMOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 742);
            this.Controls.Add(this.BTNVendors);
            this.Controls.Add(this.BTNCheckInventory);
            this.Controls.Add(this.BTNClearForm);
            this.Controls.Add(this.BTNClose);
            this.Controls.Add(this.TXTOrderTotal);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.BTNProcessOrder);
            this.Controls.Add(this.LBXFinalOrder);
            this.Controls.Add(this.GBXDeliveryAddress);
            this.Controls.Add(this.GBXOrderInformation);
            this.Controls.Add(this.GBXAddressInformation);
            this.Controls.Add(this.GBXCustomerInformation);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1017, 789);
            this.MinimumSize = new System.Drawing.Size(1017, 789);
            this.Name = "FRMOrder";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kirby\'s Deli Order Form";
            this.Load += new System.EventHandler(this.FRMOrder_Load);
            this.GBXCustomerInformation.ResumeLayout(false);
            this.GBXCustomerInformation.PerformLayout();
            this.GBXAddressInformation.ResumeLayout(false);
            this.GBXAddressInformation.PerformLayout();
            this.GBXOrderInformation.ResumeLayout(false);
            this.GBXOrderInformation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PBOFoodImg)).EndInit();
            this.GBXDeliveryAddress.ResumeLayout(false);
            this.GBXDeliveryAddress.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton RDOCarryOut;
        private System.Windows.Forms.GroupBox GBXCustomerInformation;
        private System.Windows.Forms.TextBox TXTPhoneNumber;
        private System.Windows.Forms.TextBox TXTName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox GBXAddressInformation;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox GBXOrderInformation;
        private System.Windows.Forms.TextBox TXTZipCode;
        private System.Windows.Forms.TextBox TXTState;
        private System.Windows.Forms.TextBox TXTCity;
        private System.Windows.Forms.TextBox TXTSubdivision;
        private System.Windows.Forms.TextBox TXTStreetAddress;
        private System.Windows.Forms.Button BTNClearForm;
        private System.Windows.Forms.Button BTNAddItem;
        private System.Windows.Forms.TextBox TXTQuantity;
        private System.Windows.Forms.ComboBox CBOBreadType;
        private System.Windows.Forms.ComboBox CBOFoodType;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton RDODeliver;
        private System.Windows.Forms.GroupBox GBXDeliveryAddress;
        private System.Windows.Forms.TextBox TXTDeliveryZipCode;
        private System.Windows.Forms.TextBox TXTDeliveryState;
        private System.Windows.Forms.TextBox TXTDeliveryCity;
        private System.Windows.Forms.TextBox TXTDeliverySubdivision;
        private System.Windows.Forms.TextBox TXTDeliveryStreetAddress;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox LBXFinalOrder;
        private System.Windows.Forms.Button BTNProcessOrder;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox TXTOrderTotal;
        private System.Windows.Forms.Button BTNClose;
        private System.Windows.Forms.CheckBox CHKDeliveryAddress;
        private System.Windows.Forms.PictureBox PBOFoodImg;
        private System.Windows.Forms.Button BTNCheckInventory;
        private System.Windows.Forms.Button BTNVendors;
    }
}

