﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.AspNetCore.Mvc.ViewFeatures;    // ViewContext attribute
using Microsoft.AspNetCore.Mvc.Rendering;       // ViewContext data type

namespace SportsPro.TagHelpers
{
    [HtmlTargetElement("a")]
    public class ActiveNavLinkTagHelper : TagHelper
    {
        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewCtx { get; set; } = null!;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            /**************************************************************************
             * since class attribute also contains the CSS class nav-item, difficult to
             * select using Attributes property of HtmlTargetElement attribute. So use
             * AllAttributes dictionary of TagHelperContext class instead to make sure 
             * tag helper applies to correct <a> element 
             **************************************************************************/
            var css = context.AllAttributes["class"]?.Value?.ToString() ?? "";
            if (css.Contains("nav-link"))
            {
                string ctlr = ViewCtx.RouteData.Values["controller"]?.ToString()!;
                string action = ViewCtx.RouteData.Values["action"]?.ToString()!;

                string aspCtlr = context.AllAttributes["asp-controller"]?.Value?.ToString()!;
                string aspAction = context.AllAttributes["asp-action"]?.Value?.ToString()!;

                // for home and accounts controllers, match controller and action.
                // Otherwise, match controller only.
                if (ctlr == aspCtlr) {
                    if (ctlr == "Home" || ctlr == "Account") {
                        if (action == aspAction) {
                            output.Attributes.AppendCssClass("active");
                        } 
                    } 
                    else {
                        output.Attributes.AppendCssClass("active");
                    }
                }
            }
        }

    }
}
