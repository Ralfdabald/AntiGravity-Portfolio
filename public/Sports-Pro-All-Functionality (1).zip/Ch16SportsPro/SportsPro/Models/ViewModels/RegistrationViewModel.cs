﻿namespace SportsPro.Models
{
    public class RegistrationViewModel
    {
        public Product Product { get; set; } = null!;
        public Customer Customer { get; set; } = null!;

        public bool HasProduct => Product?.ProductID > 0;
        public bool HasCustomer => Customer?.CustomerID > 0;
    }
}
