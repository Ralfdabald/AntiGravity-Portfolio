﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: CrewController.cs 
//PURPOSE: This controller manages CRUD operations for Crews and their assignments to employees.
//INITIALIZE: Requires proper Crew and Employee models, migrations, and the database context to be configured.
//INPUT: User inputs crew information via forms in the views.
//PROCESS: Retrieves, adds, edits, and deletes crews. Assigns employees as Crew Foreman, Crew Member 1, and Crew Member 2.
//OUTPUT: Displays crew listings and forms for creating or editing crews.
//TERMINATE: Uses Entity Framework Core; the database connection is closed when the application stops.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using JasperGreenTeam11.Models; 

namespace JasperGreenTeam11.Controllers
{
    public class CrewController : Controller
    {
        private JasperGreenContext context { get; set; }
        public CrewController(JasperGreenContext ctx) => context = ctx;

        public IActionResult Index() => RedirectToAction("List");
        public IActionResult List()
        {
            var crews = context.Crews
            .Include(c => c.CrewForeman)
            .Include(c => c.CrewMember1)
            .Include(c => c.CrewMember2)
            .OrderBy(c => c.CrewId)
            .ToList();

            return View(crews);
        }
        // GET: Crew/AddEdit/5
        public async Task<IActionResult> AddEdit(int? id)
        {
            PopulateEmployeeDropdown();
            if (id == null || id == 0)
            {
                return View(new Crew());
            }

            var crew = await context.Crews.FindAsync(id);
            if (crew == null)
            {
                return NotFound();
            }

            return View(crew);
        }

        // POST: Crew/AddEdit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Save(Crew crew)
        {
            if (ModelState.IsValid)
            {
                if (crew.CrewId == 0)
                {
                    context.Crews.Add(crew);
                }
                else
                {
                    context.Crews.Update(crew);
                }

                await context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            PopulateEmployeeDropdown();
            return View("AddEdit", crew);
        }

        // GET: Crew/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }

            var crew = await context.Crews
                .Include(c => c.CrewForeman)
                .Include(c => c.CrewMember1)
                .Include(c => c.CrewMember2)
                .FirstOrDefaultAsync(m => m.CrewId == id);

            if (crew == null)
            {
                return NotFound();
            }

            return View(crew);
        }

        // POST: Crew/DeleteConfirmed/5
        [HttpPost, ActionName("DeleteConfirmed")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var crew = await context.Crews.FindAsync(id);
            if (crew != null)
            {
                context.Crews.Remove(crew);
                await context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private void PopulateEmployeeDropdown()
        {
            var employees = context.Employees
                .Select(e => new SelectListItem
                {
                    Value = e.EmployeeId.ToString(),
                    Text = e.FirstName + " " + e.LastName
                })
                .ToList();

            ViewBag.EmployeeList = employees;
        }
    }
}
