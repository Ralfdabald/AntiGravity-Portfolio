﻿using JasperGreenTeam11.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JasperGreenTeam11.Controllers
{
    public class PaymentController : Controller
    {
        private JasperGreenContext context { get; set; }
        public PaymentController(JasperGreenContext ctx) => context = ctx;


        public IActionResult Index() => RedirectToAction("List");

        // Service Event List
        public IActionResult List()
        {
            var events = context.Payments.ToList();
            return View(events);
        }

        public IActionResult Add()
        {
            ViewBag.Action = "Add";



            return View("AddEdit", new Payment());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";



            var payment = context.Payments.Find(id);
            return View("AddEdit", payment);
        }

        [HttpPost]
        public IActionResult Save(Payment payment)
        {
            if (ModelState.IsValid)
            {
                if (payment.PaymentId == 0)
                {
                    context.Payments.Add(payment);
                }
                else
                {
                    context.Payments.Update(payment);
                }
                context.SaveChanges();
                TempData["SuccessMessage"] = "Payment Saved successfully.";
                return RedirectToAction("List");
            }
            else
            {
                if (payment.PaymentId == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }

                return View("AddEdit", payment);
            }
        }
        // Delete
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var payment = context.Payments.Find(id);
            if (payment == null) return NotFound();
            return View(payment);
        }

        [HttpPost]
        public IActionResult DeleteConfirmed(int id)
        {
            var payment = context.ProvideService.Find(id);
            if (payment != null)
            {
                context.ProvideService.Remove(payment);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
