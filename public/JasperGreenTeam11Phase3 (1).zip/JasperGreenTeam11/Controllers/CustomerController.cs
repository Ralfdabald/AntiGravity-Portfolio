﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: CustomerController.cs 
//PURPOSE: This program manages customer-related operations, allowing users to create, read, update, and delete
// customer records through a web interface.
//INITIALIZE: Requires a Customer model, views (List, AddEdit, Delete), and the JasperGreenContext connected 
// to a valid database with seeded customer data.
//INPUT: User inputs include first name, last name, phone, email, and address fields during add/edit operations.
//PROCESS: Displays a sorted list of customers by last name. Handles form submissions for add/edit actions 
// and deletes selected customers from the database upon confirmation.
//OUTPUT: Renders an updated customer list and form views depending on user actions. Changes are persisted to 
// the database using Entity Framework Core.
//TERMINATE: Entity Framework Core handles database connections, which are closed when the application ends.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

using Microsoft.AspNetCore.Mvc;
using JasperGreenTeam11.Models;
using Microsoft.EntityFrameworkCore;

namespace JasperGreenTeam11.Controllers
{
    public class CustomerController : Controller
    {
        private JasperGreenContext context { get; set; }
        public CustomerController(JasperGreenContext ctx) => context = ctx;

        public IActionResult Index() => RedirectToAction("List");

        public IActionResult List()
        {
            
            var customers = context.Customers.OrderBy(c => c.CustomerId).ToList();
            return View(customers);
        }
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";

            

            return View("AddEdit", new Customer());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";

            

            var customer = context.Customers.Find(id);
            return View("AddEdit", customer);
        }

        [HttpPost]
        public IActionResult Save(Customer customer)
        {
            if (ModelState.IsValid)
            {
                if (customer.CustomerId == 0)
                {
                    context.Customers.Add(customer);
                    TempData["SuccessMessage"] = "Customer added successfully.";
                }
                else
                {
                    context.Customers.Update(customer);
                    TempData["SuccessMessage"] = "Customer updated successfully.";
                }
                context.SaveChanges();
                return RedirectToAction("List");
            }
            else
            {
                if (customer.CustomerId == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }
                
                return View("AddEdit", customer);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var customer = context.Customers.Find(id);
            return View(customer);
        }

        [HttpPost]
        public IActionResult Delete(Customer customer)
        {
            try
            {
                context.Customers.Remove(customer);
                context.SaveChanges();
                
            }
            catch (DbUpdateException)
            {
                TempData["message"] = $"{customer} cannot be deleted because there are related records in the system.";
            }
            return RedirectToAction("List");
        }
    }
}
