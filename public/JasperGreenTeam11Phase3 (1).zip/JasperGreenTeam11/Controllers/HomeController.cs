//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: HomeController.cs 
//PURPOSE: This controller handles the basic routing and landing page of the application. It directs users to 
// the homepage and manages basic error handling for the app.
//INITIALIZE: This controller requires minimal setup and works with the default layout and shared views provided 
// in an ASP.NET MVC project structure.
//INPUT: User actions such as navigating to the home page or encountering an application error.
//PROCESS: Returns the main index view of the site and handles unexpected application errors gracefully by 
// showing an error view with diagnostics information.
//OUTPUT: Displays the homepage (Index view) and, when necessary, the Error view with relevant details.
//TERMINATE: The controller stops executing when the user leaves the page or closes the application.
//HONOR CODE: �On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.�

using System.Diagnostics;
using JasperGreenTeam11.Models;
using Microsoft.AspNetCore.Mvc;

namespace JasperGreenTeam11.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
