﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: EmployeeController.cs 
//PURPOSE: This program manages employee-related functionality, allowing users to perform CRUD (Create, Read, 
// Update, Delete) operations on employee records.
//INITIALIZE: Requires an Employee model, views (List, AddEdit, Delete), and the JasperGreenContext connected 
// to a database with employee data seeded or manually added.
//INPUT: User inputs include employee first name, last name, and role during add/edit actions.
//PROCESS: Displays a sorted list of employees by last name. Handles user requests to add new employees, edit 
// existing ones, and delete employees from the system.
//OUTPUT: Renders the employee list and appropriate form views. Saves changes made by the user to the database 
// using Entity Framework Core.
//TERMINATE: Database connections are managed and closed by Entity Framework Core when the application stops.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

using Microsoft.AspNetCore.Mvc;
using JasperGreenTeam11.Models;
using Microsoft.EntityFrameworkCore;

namespace JasperGreenTeam11.Controllers
{
    public class EmployeeController : Controller
    {
        private JasperGreenContext context { get; set; }
        public EmployeeController(JasperGreenContext ctx) => context = ctx;

        public IActionResult Index() => RedirectToAction("List");

        public IActionResult List()
        {
            var employee = context.Employees.OrderBy(c => c.EmployeeId).ToList();
            return View(employee);
        }
        [HttpGet]
        public IActionResult Add()
        {
            ViewBag.Action = "Add";



            return View("AddEdit", new Employee());
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Action = "Edit";



            var employee = context.Employees.Find(id);
            return View("AddEdit", employee);
        }

        [HttpPost]
        public IActionResult Save(Employee employee)
        {
            if (ModelState.IsValid)
            {
                if (employee.EmployeeId == 0)
                {
                    context.Employees.Add(employee);
                }
                else
                {
                    context.Employees.Update(employee);
                }
                context.SaveChanges();
                return RedirectToAction("List");
            }
            else
            {
                if (employee.EmployeeId == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }

                return View("AddEdit", employee);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var employee = context.Employees.Find(id);
            return View(employee);
        }

        [HttpPost]
        public IActionResult Delete(Employee employee)
        {
            try
            {
                context.Employees.Remove(employee);
                context.SaveChanges();

            }
            catch (DbUpdateException)
            {
                TempData["message"] = $" cannot be deleted because there are related records in the system.";
            }
            return RedirectToAction("List");
        }
    }
}
