﻿using JasperGreenTeam11.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace JasperGreenTeam11.Controllers
{
    public class ProvideServiceController : Controller
    {
        private JasperGreenContext context { get; set; }
        public ProvideServiceController(JasperGreenContext ctx) => context = ctx;


        public IActionResult Index() => RedirectToAction("List");

        // Service Event List
        public IActionResult List()
        {
            var events = context.ProvideService.ToList();
            return View(events);
        }

        // Add
        [HttpGet]
        public IActionResult Add()
        {
            var serviceEvent = new ProvideService { ServiceDate = DateTime.Now };
            return View("AddEdit", serviceEvent);
        }

        [HttpPost]
        public IActionResult Add(ProvideService serviceEvent)
        {
            if (ModelState.IsValid)
            {
                context.ProvideService.Add(serviceEvent);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View("AddEdit", serviceEvent);
        }

        // Edit
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var serviceEvent = context.ProvideService.Find(id);
            if (serviceEvent == null) return NotFound();
            return View("AddEdit", serviceEvent);
        }

        [HttpPost]
        public IActionResult Edit(ProvideService serviceEvent)
        {
            if (ModelState.IsValid)
            {
                context.ProvideService.Update(serviceEvent);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View("AddEdit", serviceEvent);
        }

        // Delete
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var serviceEvent = context.ProvideService.Find(id);
            if (serviceEvent == null) return NotFound();
            return View(serviceEvent);
        }

        [HttpPost]
        public IActionResult DeleteConfirmed(int id)
        {
            var serviceEvent = context.ProvideService.Find(id);
            if (serviceEvent != null)
            {
                context.ProvideService.Remove(serviceEvent);
                context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        // Payment
        [HttpGet]
        public IActionResult Payment(int id)
        {
            var payment = new Payment { Date = DateTime.Now, PaymentId = id };
            return View(payment);
        }

        [HttpPost]
        public IActionResult Payment(Payment payment)
        {
            if (ModelState.IsValid)
            {
                context.Payments.Add(payment);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(payment);
        }

        // Filter By Customer
        [HttpGet]
        public IActionResult GetCustomer()
        {
            ViewBag.Customers = context.Customers.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetCustomer(int customerId)
        {
            var events = context.ProvideService.Where(e => e.CustomerId == customerId).ToList();
            return View("Index", events);
        }

        // Filter By Property
        [HttpGet]
        public IActionResult GetProperty()
        {
            ViewBag.Properties = context.Properties.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetProperty(int propertyId)
        {
            var events = context.ProvideService.Where(e => e.PropertyId == propertyId).ToList();
            return View("Index", events);
        }

        // Filter By Crew
        [HttpGet]
        public IActionResult GetCrew()
        {
            ViewBag.Crews = context.Crews.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetCrew(int crewId)
        {
            var events = context.ProvideService.Where(e => e.CrewId == crewId).ToList();
            return View("Index", events);
        }
    }
}
