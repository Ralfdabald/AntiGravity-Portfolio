﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: Employee.cs 
//PURPOSE: Defines the Employee model representing employees assigned to crews with specific roles.
//INITIALIZE: Included in the Entity Framework Core context (JasperGreenContext) to support DB operations.
//INPUT: Employee information such as first name, last name, role, and associated crew relationships.
//PROCESS: Supports entity relationships with Crew model including CrewForeman, CrewMember1, and CrewMember2 roles. Used for employee data entry and validation.
//OUTPUT: Provides data structure to interact with Razor views and controllers for managing employees.
//TERMINATE: Managed automatically by Entity Framework Core.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JasperGreenTeam11.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }

        [Required, MaxLength(50)]
        public string FirstName { get; set; }

        [Required, MaxLength(50)]
        public string LastName { get; set; }

        public string? Role { get; set; }
        // Foreign Key for Crew (the crew the employee is part of)
        public int? CrewId { get; set; }
        [ForeignKey("CrewId")]
        public Crew? Crew { get; set; } // Reference to the Crew
        

        
        
        public string FullName => $"{FirstName} {LastName}";

        // Navigation: Crews where this employee is the Foreman
        public ICollection<Crew>? CrewForeman { get; set; }

        // Navigation: Crews where this employee is CrewMember1
        public ICollection<Crew>? CrewMember1 { get; set; }

        // Navigation: Crews where this employee is CrewMember2
        public ICollection<Crew>? CrewMember2 { get; set; }
    }
}
