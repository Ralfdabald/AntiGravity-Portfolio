﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//AUTHOR:   Zoe Cruz, Cassandra Elizondo, Collin Fuchs, Josh High, Tyler Kwan
//COURSE:   ISTM 250.501
//FORM:  FRMInventory.cs
//PURPOSE: Create a form that takes the amount of product used for each order,
//   subtracts it from product amount, and outputs product and quantity to a
//   listbox.
//INPUT:   Product list, array of the current product quantities.
//PROCESS: Clear is used to clear the listbox.
//   ShowingArray is used to copy the array from the order form.
//   Products/quantities are formatted and added to the listbox.
//OUTPUT:  Listbox of the products and their respective quantities.
//HONOR CODE: “On my honor, as an Aggie, I have neither given  
//   nor received unauthorized aid on this academic  
//   work.”
namespace GroupBProject1
{
    public partial class FRMInventory : Form
    {
        public FRMInventory()
        {
            InitializeComponent();
        }
        //string array of all product names
        string[] strProductNames = { "Flour","Yeast","Sugar","Oil","Ham","Turkey","SCheese","Lettuce","Tomato",
                                    "Bacon","Pickles","Mayo","Mustard","Pepperoni","Sauce","GCheese","Salt","Pepper" };
        //declares empty array to store Order form array into
        decimal[] decProductAmount = { 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m, 0m };
        
        /// <summary>
        /// fills the listbox with the product item and its quantity when form loads
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void FRMInventory_Load(object sender, EventArgs e)
        {
            // clears the list box from any previous inventory calculation 
            LBXInventory.Items.Clear();
            
            // adds the product names along with their quantity to the listbox
            for (int i = 0; i < strProductNames.Length; i++)
            {
                LBXInventory.Items.Add(strProductNames[i] + ": " + decProductAmount[i] + "\n");
            }
        }
        /// <summary>
        /// method to get the array from the order form
        /// </summary>
        /// <param name="decProductTotals"></param>
        public void ShowingArray(decimal[] decProductTotals)
        {
            //transfers order form array into an array that is usable in this form
            for(int i = 0; i < decProductTotals.Length; i++)
            {
                decProductAmount[i] = decProductTotals[i];
            }
        }
    }
}
