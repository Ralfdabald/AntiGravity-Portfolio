﻿using Microsoft.AspNetCore.Identity;

namespace SportsPro.Models
{
    public class User : IdentityUser
    {
    }
}
