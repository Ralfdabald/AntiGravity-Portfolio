﻿namespace SportsPro.Models
{
    public class IncidentViewModel
    {
        public Incident Incident { get; set; } = null!;
        public string Action { get; set; } = string.Empty;
    }
}
