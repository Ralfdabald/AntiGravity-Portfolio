﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: ProvideService.cs
//PURPOSE: This model defines the structure of the ProvideService entity, representing services that are provided to properties in the JasperGreen system. 
// It links a specific property to a service and tracks the details of the service, such as the service type, date provided, and the associated crew members who performed the service.
//INITIALIZE: The ProvideService model must be configured in the JasperGreenContext class and migrations should be run to add this table to the database.
// It should also establish relationships with related entities such as Crew, Property, and potentially ServiceType models. 
// This model is key for tracking services performed on properties and assigning crews to these services.
//INPUT: This model stores details of the service provided, including a foreign key to the Property entity, the type of service, 
// the date it was performed, and links to the crews that performed the service.
//PROCESS: The model ensures that all service-related data is properly linked between properties, services, and crew members. 
// It provides functionality for tracking services performed and scheduling future services if required.
//OUTPUT: This entity can be queried to track past services provided to properties, including service types, crew members, 
// and service dates, enabling better property maintenance management.
//TERMINATE: Data in the ProvideService table will be stored and managed by Entity Framework Core, with updates reflecting the service history of properties.
// The connection to the database is managed through the EF Core context throughout the application runtime.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

namespace JasperGreenTeam11.Models
{
    public class ProvideService
    {
        public int? ProvideServiceId { get; set; }
        public int PropertyId { get; set; }
        
        public int ServiceName { get; set; }
        public int CrewId { get; set; }
        public string? ServiceType { get; set; }
        public decimal Price { get; set; }
        public DateTime ServiceDate { get; set; }
        
        // Navigation properties
        public Property? Property { get; set; }
        public Crew? Crew { get; set; }
        public int? CustomerId { get; internal set; }
    }
}
