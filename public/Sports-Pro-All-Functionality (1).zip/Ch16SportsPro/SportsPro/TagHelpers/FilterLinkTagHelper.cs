﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.AspNetCore.Mvc.ViewFeatures;    // ViewContext attribute
using Microsoft.AspNetCore.Mvc.Rendering;       // ViewContext data type

namespace SportsPro.TagHelpers
{
    [HtmlTargetElement(Attributes = "my-filter")]
    public class FilterLinkTagHelper : TagHelper
    {
        [ViewContext]
        [HtmlAttributeNotBound]
        public ViewContext ViewCtx { get; set; } = null!;

        [HtmlAttributeName("my-filter")]
        public string Filter { get; set; } = string.Empty;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            string id = context.AllAttributes["asp-route-id"]?.Value?.ToString() ?? "";

            if (id == Filter)
                output.Attributes.AppendCssClass("active");
        }

    }
}
