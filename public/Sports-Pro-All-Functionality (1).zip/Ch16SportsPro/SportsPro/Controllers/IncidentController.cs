﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportsPro.Models;

namespace SportsPro.Controllers
{
    [Authorize(Roles = "Admin")]
    public class IncidentController : Controller
    {
        private IRepository<Incident> incidentData { get; set; }
        public IncidentController(IRepository<Incident> incidentRep) => incidentData = incidentRep;

        public IActionResult Index() => RedirectToAction("List");

        [Route("[controller]s/{filter?}")]
        public IActionResult List(string filter = "all")
        {
            var options = new QueryOptions<Incident> { 
                Includes = "Customer, Product",
                OrderBy = i => i.DateOpened
            };
            if (filter == "unassigned") {
                options.Where = i => i.TechnicianID == -1;
            }
            if (filter == "open") {
                options.Where = i => i.DateClosed == null;
            }

            var model = new IncidentListViewModel
            {
                Filter = filter,
                Incidents = incidentData.List(options)
            };

            return View(model);
        }

        public IActionResult Filter(string id)
        {
            return RedirectToAction("List", new { Filter = id });
        }

        [HttpGet]
        public IActionResult Add()
        {
            var model = new IncidentViewModel
            {
                Action = "Add",
                Incident = new Incident()
            };

            return View("AddEdit", model);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var model = new IncidentViewModel
            {
                Action = "Edit",
                Incident = incidentData.Get(id)!
            };

            return View("AddEdit", model);
        }

        [HttpPost]
        public IActionResult Save(Incident incident)
        {
            if (ModelState.IsValid)
            {
                if (incident.IncidentID == 0)
                {
                    incidentData.Insert(incident);
                }
                else
                {
                    incidentData.Update(incident);
                }
                incidentData.Save();
                return RedirectToAction("List");
            }
            else
            {
                var model = new IncidentViewModel
                {
                    Incident = incident
                };

                if (incident.IncidentID == 0)
                {
                    model.Action = "Add";
                }
                else
                {
                    model.Action = "Edit";
                }

                return View("AddEdit", model);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var product = incidentData.Get(id);
            return View(product);
        }

        [HttpPost]
        public IActionResult Delete(DeleteViewModel model)
        {
            var incident = new Incident { IncidentID = model.Id };
            incidentData.Delete(incident);
            incidentData.Save();
            return RedirectToAction("List");
        }
    }
}