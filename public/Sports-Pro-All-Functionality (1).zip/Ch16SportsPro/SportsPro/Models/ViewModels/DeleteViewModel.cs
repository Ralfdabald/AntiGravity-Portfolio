﻿namespace SportsPro.Models
{
    public class DeleteViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
