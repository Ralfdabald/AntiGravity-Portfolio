﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: Property.cs
//PURPOSE: This model defines the structure of the Property entity, representing properties managed in the JasperGreen application. 
// It contains information about each property, such as its address, city, state, zip code, and links to related entities like customers and crews.
//INITIALIZE: The Property model is used to track properties, their addresses, and associated customers or crews. Migrations should be created 
// to add the Property table to the database, and the necessary relationships with the Customer and Crew models should be set up 
// in the JasperGreenContext class.
//INPUT: The properties contain the data entered by the user, including the address, city, state, zip code, and foreign keys 
// for customer and crews. These values are stored in the database.
//PROCESS: This model tracks property details, including the customer who owns the property and the crews responsible for property 
// management or maintenance. It ensures that all data is properly stored and retrieved in relation to other entities.
//OUTPUT: The entity records property details for each property, which can be queried for real estate management purposes, 
// customer analysis, and other operational reports in the JasperGreen application.
//TERMINATE: The property data will be stored in the database via Entity Framework Core. The connection is managed by the EF Core context 
// throughout the application runtime.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

using System.ComponentModel.DataAnnotations;

namespace JasperGreenTeam11.Models
{
    public class Property
    {
        public int PropertyId { get; set; }

        [MaxLength(100)]
        public string? Street { get; set; }

        [MaxLength(50)]
        public string? City { get; set; }

        [MaxLength(2)]
        public string? State { get; set; }

        [MaxLength(10)]
        public string? Zip { get; set; }

        [MaxLength(100)]
        public string? Address { get; set; }

        // Foreign Key
        public int CustomerId { get; set; }
        public Customer? Customer { get; set; }

        // Foreign Keys for Crew Members
        public int? CrewForemanId { get; set; }
        public Employee? CrewForeman { get; set; }

        public int? CrewMember1Id { get; set; }
        public Employee? CrewMember1 { get; set; }

        public int? CrewMember2Id { get; set; }
        public Employee? CrewMember2 { get; set; }

        // Navigation property for crews assigned to this property
        public ICollection<Crew>? Crews { get; set; }
    }
}
