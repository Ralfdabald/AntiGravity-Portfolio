﻿using Microsoft.AspNetCore.Mvc;
using SportsPro.Models;

namespace SportsPro.Components
{
    public class Delete : ViewComponent
    {
        public IViewComponentResult Invoke(int id, string name)
        {
            var model = new DeleteViewModel { 
                Id = id,
                Name = name
            };
            return View(model);
        }
    }
}
