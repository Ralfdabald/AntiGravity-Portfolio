﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SportsPro.Models;

namespace SportsPro.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ProductController : Controller
    {
        private IRepository<Product> data { get; set; }
        public ProductController(IRepository<Product> rep) => data = rep;

        public RedirectToActionResult Index() => RedirectToAction("List");

        [Route("[controller]s")]
        public ViewResult List()
        {
            var products = data.List(new QueryOptions<Product> { OrderBy = p => p.ReleaseDate });
            return View(products);
        }

        [HttpGet]
        public ViewResult Add()
        {
            ViewBag.Action = "Add";
            return View("AddEdit", new Product());
        }

        [HttpGet]
        public ViewResult Edit(int id)
        {
            ViewBag.Action = "Edit";
            var product = data.Get(id);
            return View("AddEdit", product);
        }

        [HttpPost]
        public IActionResult Save(Product product)
        {
            string message = string.Empty;
            if (ModelState.IsValid)
            {
                if (product.ProductID == 0)
                {
                    data.Insert(product);
                    message = product.Name + " was added.";
                }
                else
                {
                    data.Update(product);
                    message = product.Name + " was updated.";
                }
                data.Save();
                TempData["message"] = message;
                return RedirectToAction("List");
            }
            else
            {
                if (product.ProductID == 0)
                {
                    ViewBag.Action = "Add";
                }
                else
                {
                    ViewBag.Action = "Edit";
                }                    
                return View(product);
            }
        }

        [HttpGet]
        public ViewResult Delete(int id)
        {
            var product = data.Get(id);
            return View(product);
        }

        [HttpPost]
        public RedirectToActionResult Delete(DeleteViewModel model)
        {
            var product = new Product { ProductID = model.Id };  
            data.Delete(product);
            data.Save();
            TempData["message"] = model.Name + " was deleted.";
            return RedirectToAction("List");
        }
    }
}