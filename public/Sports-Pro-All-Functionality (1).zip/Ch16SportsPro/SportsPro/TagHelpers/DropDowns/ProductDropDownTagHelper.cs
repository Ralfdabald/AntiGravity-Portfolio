﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using SportsPro.Models;

namespace SportsPro.TagHelpers
{
    [HtmlTargetElement(Attributes = "my-products")]
    public class ProductDropDownTagHelper : BaseDropDownTagHelper
    {
        private IRepository<Product> data { get; set; }
        public ProductDropDownTagHelper(IRepository<Product> rep) => data = rep;

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            string selectedValue = base.GetSelectedValue(context);

            // get list from database
            var products = data.List(new QueryOptions<Product> { OrderBy = p => p.Name });

            // add default option
            base.AddOption(output, "Select a product...", "");

            // add rest of options 
            foreach (var product in products)
            {
                base.AddOption(output, product.Name, product.ProductID.ToString(), selectedValue);
            }

        }

    }
}
