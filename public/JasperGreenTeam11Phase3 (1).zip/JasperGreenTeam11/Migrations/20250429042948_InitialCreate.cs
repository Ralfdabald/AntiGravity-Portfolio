﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace JasperGreenTeam11.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    CustomerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    State = table.Column<string>(type: "nvarchar(2)", maxLength: 2, nullable: false),
                    Zip = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.CustomerId);
                });

            migrationBuilder.CreateTable(
                name: "CrewProperty",
                columns: table => new
                {
                    CrewsCrewId = table.Column<int>(type: "int", nullable: false),
                    PropertiesPropertyId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CrewProperty", x => new { x.CrewsCrewId, x.PropertiesPropertyId });
                });

            migrationBuilder.CreateTable(
                name: "Crews",
                columns: table => new
                {
                    CrewId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CrewName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CrewForemanID = table.Column<int>(type: "int", nullable: true),
                    CrewMember1ID = table.Column<int>(type: "int", nullable: true),
                    CrewMember2ID = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Crews", x => x.CrewId);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    EmployeeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Role = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CrewId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.EmployeeId);
                    table.ForeignKey(
                        name: "FK_Employees_Crews_CrewId",
                        column: x => x.CrewId,
                        principalTable: "Crews",
                        principalColumn: "CrewId");
                });

            migrationBuilder.CreateTable(
                name: "Properties",
                columns: table => new
                {
                    PropertyId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Street = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    City = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    State = table.Column<string>(type: "nvarchar(2)", maxLength: 2, nullable: true),
                    Zip = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: true),
                    Address = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CustomerId = table.Column<int>(type: "int", nullable: false),
                    CrewForemanId = table.Column<int>(type: "int", nullable: true),
                    CrewMember1Id = table.Column<int>(type: "int", nullable: true),
                    CrewMember2Id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Properties", x => x.PropertyId);
                    table.ForeignKey(
                        name: "FK_Properties_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "CustomerId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Properties_Employees_CrewForemanId",
                        column: x => x.CrewForemanId,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId");
                    table.ForeignKey(
                        name: "FK_Properties_Employees_CrewMember1Id",
                        column: x => x.CrewMember1Id,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId");
                    table.ForeignKey(
                        name: "FK_Properties_Employees_CrewMember2Id",
                        column: x => x.CrewMember2Id,
                        principalTable: "Employees",
                        principalColumn: "EmployeeId");
                });

            migrationBuilder.CreateTable(
                name: "ProvideService",
                columns: table => new
                {
                    ProvideServiceId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PropertyId = table.Column<int>(type: "int", nullable: false),
                    ServiceName = table.Column<int>(type: "int", nullable: false),
                    CrewId = table.Column<int>(type: "int", nullable: false),
                    ServiceType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Price = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    ServiceDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CustomerId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProvideService", x => x.ProvideServiceId);
                    table.ForeignKey(
                        name: "FK_ProvideService_Crews_CrewId",
                        column: x => x.CrewId,
                        principalTable: "Crews",
                        principalColumn: "CrewId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProvideService_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "CustomerId");
                    table.ForeignKey(
                        name: "FK_ProvideService_Properties_PropertyId",
                        column: x => x.PropertyId,
                        principalTable: "Properties",
                        principalColumn: "PropertyId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Payments",
                columns: table => new
                {
                    PaymentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ProvideServiceId = table.Column<int>(type: "int", nullable: true),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", precision: 18, scale: 2, nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    PaymentMethod = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomerId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payments", x => x.PaymentId);
                    table.ForeignKey(
                        name: "FK_Payments_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "CustomerId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Payments_ProvideService_ProvideServiceId",
                        column: x => x.ProvideServiceId,
                        principalTable: "ProvideService",
                        principalColumn: "ProvideServiceId");
                });

            migrationBuilder.InsertData(
                table: "Crews",
                columns: new[] { "CrewId", "CrewForemanID", "CrewMember1ID", "CrewMember2ID", "CrewName" },
                values: new object[,]
                {
                    { 1, null, null, null, "Green Team A" },
                    { 2, null, null, null, "Landscapers B" },
                    { 3, null, null, null, "Maintenance Crew C" },
                    { 4, null, null, null, "Tree Trimmers D" },
                    { 5, null, null, null, "Lawn Care E" }
                });

            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "CustomerId", "Address", "City", "Email", "FirstName", "LastName", "Phone", "State", "Zip" },
                values: new object[,]
                {
                    { 1, "", "", "john@example.com", "John", "Doe", "555-1234", "", "" },
                    { 2, "", "", "jane@example.com", "Jane", "Smith", "555-5678", "", "" },
                    { 3, "", "", "alice@example.com", "Alice", "Brown", "555-8765", "", "" },
                    { 4, "", "", "bob@example.com", "Bob", "Green", "555-4321", "", "" },
                    { 5, "", "", "charlie@example.com", "Charlie", "White", "555-9876", "", "" }
                });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "EmployeeId", "CrewId", "FirstName", "LastName", "Role" },
                values: new object[,]
                {
                    { 1, 1, "Ethan", "Wilson", null },
                    { 2, 1, "Sophia", "Davis", null },
                    { 3, 2, "Michael", "Johnson", null },
                    { 4, 2, "Olivia", "Martinez", null },
                    { 5, 3, "Daniel", "Brown", null },
                    { 6, 3, "Emma", "Anderson", null },
                    { 7, 4, "James", "White", null },
                    { 8, 4, "Isabella", "Thompson", null },
                    { 9, 5, "Benjamin", "Lewis", null },
                    { 10, 5, "Charlotte", "Hall", null },
                    { 11, 1, "Mason", "Scott", null },
                    { 12, 2, "Liam", "Clark", null },
                    { 13, 3, "Ava", "Young", null },
                    { 14, 4, "William", "Hernandez", null },
                    { 15, 5, "Emily", "King", null }
                });

            migrationBuilder.InsertData(
                table: "Payments",
                columns: new[] { "PaymentId", "Amount", "CustomerId", "Date", "PaymentMethod", "ProvideServiceId" },
                values: new object[,]
                {
                    { 1, 150.00m, 1, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Credit Card", null },
                    { 2, 200.00m, 2, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "PayPal", null },
                    { 3, 100.00m, 3, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Debit Card", null },
                    { 4, 250.00m, 4, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Bank Transfer", null },
                    { 5, 180.00m, 5, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Cash", null }
                });

            migrationBuilder.InsertData(
                table: "Properties",
                columns: new[] { "PropertyId", "Address", "City", "CrewForemanId", "CrewMember1Id", "CrewMember2Id", "CustomerId", "State", "Street", "Zip" },
                values: new object[,]
                {
                    { 1, "123 Greenway Blvd", null, null, null, null, 1, null, null, null },
                    { 2, "456 Elm St", null, null, null, null, 1, null, null, null },
                    { 3, "789 Oak Dr", null, null, null, null, 2, null, null, null },
                    { 4, "101 Maple Ave", null, null, null, null, 3, null, null, null },
                    { 5, "222 Cedar Rd", null, null, null, null, 4, null, null, null },
                    { 6, "333 Pine Ln", null, null, null, null, 5, null, null, null },
                    { 7, "444 Birch Pl", null, null, null, null, 2, null, null, null },
                    { 8, "555 Walnut Ct", null, null, null, null, 3, null, null, null },
                    { 9, "666 Aspen Trl", null, null, null, null, 4, null, null, null },
                    { 10, "777 Willow Way", null, null, null, null, 5, null, null, null }
                });

            migrationBuilder.InsertData(
                table: "ProvideService",
                columns: new[] { "ProvideServiceId", "CrewId", "CustomerId", "Price", "PropertyId", "ServiceDate", "ServiceName", "ServiceType" },
                values: new object[,]
                {
                    { 1, 1, null, 50.00m, 1, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Lawn Mowing" },
                    { 2, 1, null, 75.00m, 2, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Tree Pruning" },
                    { 3, 2, null, 100.00m, 3, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Garden Maintenance" },
                    { 4, 2, null, 120.00m, 4, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Seasonal Cleanup" },
                    { 5, 3, null, 80.00m, 5, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Lawn Fertilization" },
                    { 6, 3, null, 50.00m, 6, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Lawn Mowing" },
                    { 7, 4, null, 90.00m, 7, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Mulching" },
                    { 8, 4, null, 110.00m, 8, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Pest Control" },
                    { 9, 5, null, 75.00m, 9, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Tree Pruning" },
                    { 10, 5, null, 200.00m, 10, new DateTime(2024, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, "Garden Design" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_CrewProperty_PropertiesPropertyId",
                table: "CrewProperty",
                column: "PropertiesPropertyId");

            migrationBuilder.CreateIndex(
                name: "IX_Crews_CrewForemanID",
                table: "Crews",
                column: "CrewForemanID");

            migrationBuilder.CreateIndex(
                name: "IX_Crews_CrewMember1ID",
                table: "Crews",
                column: "CrewMember1ID");

            migrationBuilder.CreateIndex(
                name: "IX_Crews_CrewMember2ID",
                table: "Crews",
                column: "CrewMember2ID");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_CrewId",
                table: "Employees",
                column: "CrewId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_CustomerId",
                table: "Payments",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_Payments_ProvideServiceId",
                table: "Payments",
                column: "ProvideServiceId");

            migrationBuilder.CreateIndex(
                name: "IX_Properties_CrewForemanId",
                table: "Properties",
                column: "CrewForemanId");

            migrationBuilder.CreateIndex(
                name: "IX_Properties_CrewMember1Id",
                table: "Properties",
                column: "CrewMember1Id");

            migrationBuilder.CreateIndex(
                name: "IX_Properties_CrewMember2Id",
                table: "Properties",
                column: "CrewMember2Id");

            migrationBuilder.CreateIndex(
                name: "IX_Properties_CustomerId",
                table: "Properties",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_ProvideService_CrewId",
                table: "ProvideService",
                column: "CrewId");

            migrationBuilder.CreateIndex(
                name: "IX_ProvideService_CustomerId",
                table: "ProvideService",
                column: "CustomerId");

            migrationBuilder.CreateIndex(
                name: "IX_ProvideService_PropertyId",
                table: "ProvideService",
                column: "PropertyId");

            migrationBuilder.AddForeignKey(
                name: "FK_CrewProperty_Crews_CrewsCrewId",
                table: "CrewProperty",
                column: "CrewsCrewId",
                principalTable: "Crews",
                principalColumn: "CrewId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CrewProperty_Properties_PropertiesPropertyId",
                table: "CrewProperty",
                column: "PropertiesPropertyId",
                principalTable: "Properties",
                principalColumn: "PropertyId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Crews_Employees_CrewForemanID",
                table: "Crews",
                column: "CrewForemanID",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Crews_Employees_CrewMember1ID",
                table: "Crews",
                column: "CrewMember1ID",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Crews_Employees_CrewMember2ID",
                table: "Crews",
                column: "CrewMember2ID",
                principalTable: "Employees",
                principalColumn: "EmployeeId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Employees_Crews_CrewId",
                table: "Employees");

            migrationBuilder.DropTable(
                name: "CrewProperty");

            migrationBuilder.DropTable(
                name: "Payments");

            migrationBuilder.DropTable(
                name: "ProvideService");

            migrationBuilder.DropTable(
                name: "Properties");

            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "Crews");

            migrationBuilder.DropTable(
                name: "Employees");
        }
    }
}
