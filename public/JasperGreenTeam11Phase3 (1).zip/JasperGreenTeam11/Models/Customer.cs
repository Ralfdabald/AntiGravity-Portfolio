﻿//AUTHOR: Josh High
//COURSE: ISTM 415.502 
//FORM: Customer.cs 
//PURPOSE: Defines the Customer model representing individual clients with personal and contact information.
//INITIALIZE: This class should be included in the Entity Framework Core model and registered in the JasperGreenContext for database interaction.
//INPUT: Customer data such as first name, last name, email, phone, and address.
//PROCESS: Provides data structure for storing and retrieving customer information. Supports CRUD operations via Razor pages and controllers.
//OUTPUT: Used in views to display and manage customer information. Enables form binding and validation.
//TERMINATE: Object lifecycle is handled by EF Core and application context.
//HONOR CODE: “On my honor, as an Aggie, I have neither given
// nor received unauthorized aid on this academic
// work.”

using System.ComponentModel.DataAnnotations;

namespace JasperGreenTeam11.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }

        [Required(ErrorMessage = "Customer first name is required.")]
        public string? FirstName { get; set; }

        [Required(ErrorMessage = "Customer last name is required.")]
        public string? LastName { get; set; }

        [Required(ErrorMessage = "Address is required.")]
        public string Address { get; set; } = string.Empty;

        [Required(ErrorMessage = "City is required.")]
        public string City { get; set; } = string.Empty;

        [Required]
        [StringLength(2, MinimumLength = 2)]
        public string State { get; set; } = string.Empty;

        [Required]
        [RegularExpression(@"^\d{5}(\d{4})?$", ErrorMessage = "ZIP must be 5 or 9 digits")]
        public string Zip { get; set; } = string.Empty;


        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string? Email { get; set; }

        [Required]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Phone must be 10 digits")]
        public string? Phone { get; set; }

        // Computed Property (No need to store in database)
        public string Name => $"{FirstName} {LastName}";

        public ICollection<Property>? Properties { get; set; }
        public ICollection<ProvideService>? ServiceEvents { get; set; }
    }
}
