﻿using JasperGreenTeam11.Models;

namespace JasperGreenTeam11.Data
{
    public class DbInitializer
    {
        public static void Seed(JasperGreenContext context)
        {
            if (!context.Customers.Any())
            {
                context.Customers.AddRange(new List<Customer>
            {
                new Customer { FirstName = "John", LastName = "Doe", Email = "john@example.com", Phone = "555-1234" },
                new Customer { FirstName = "Jane", LastName = "Smith", Email = "jane@example.com", Phone = "555-5678" }
            });

                context.SaveChanges();
            }
        }
    }
}
