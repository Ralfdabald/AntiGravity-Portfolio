﻿using System.ComponentModel.DataAnnotations;

namespace JasperGreenTeam11.Models
{
    public class CrewViewModel
    {
        public int? ID { get; set; }

        [Required] public string? CrewName { get; set; }

        [Required]
        [Display(Name = "Foreman")]
        public int? CrewForemanID { get; set; }

        [Required]
        [Display(Name = "Member 1")]
        public int? CrewMember1ID { get; set; }

        [Required]
        [Display(Name = "Member 2")]
        public int? CrewMember2ID { get; set; }

        // For dropdowns
        public IEnumerable<Employee>? Employees { get; set; }
    }
}
